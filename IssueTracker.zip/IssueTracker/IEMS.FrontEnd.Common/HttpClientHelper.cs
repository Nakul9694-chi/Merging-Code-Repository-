﻿

using IEMS.FrontEnd.Models.IssueTracker_TSG.Register;
using IEMS.FrontEnd.Models.IssueTracker_TSG.RegisterVM;
using IEMS.FrontEnd.Models.RateApproval;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace IEMS.FrontEnd.Common
{
    public static class APIURL
    {
        public static IConfiguration getProperties = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: false, reloadOnChange: false).Build();

        public static string BaseURL = getProperties.GetSection("APIURL").Value;

    }

    public static class Authentications
    {
        public static string accessToken { get; set; }
        public static void SetToken(string Token)
        {
            accessToken = Token;
        }
        public static string GetToken()
        {
            return accessToken;
        }
    }
    public static class HttpClientHelper
    {
        public static async Task<HttpResponseMessage> POSTAPI(string URL, string JsonModel, string Token = "")
        {
            using (var client = new HttpClient())
            {
                //string url = APIURL.BaseURL + URL;
                //string url = URLPORTServices.GetURL(URLPORT.Login) + URL;
                client.BaseAddress = new Uri(URL);
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Token);
                var content = new StringContent(JsonModel, Encoding.UTF8, "application/json");

                // response.Result.IsSuccessStatusCode == true and no errors
                var response = await client.PostAsync(URL, content);

                //response.Wait();

                if ((int)response.StatusCode != (int)HttpStatusCode.OK)
                {
                    var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "Oops!!!" };
                    throw new HttpResponseException(msg.Content.ToString());
                }

                return response;
            }
        }
        public static async Task<HttpResponseMessage> GetAPI(string URL, string JsonModel, string Token = "")
        {
            using (var client = new HttpClient())
            {
                // string url = APIURL.BaseURL + URL;
                // string url = URLPORTServices.GetURL(URLPORT.Login) + URL;
                client.BaseAddress = new Uri(URL);
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Token);
                client.Timeout = new TimeSpan(0, 0, 300);
                var content = new StringContent(JsonModel ?? "", Encoding.UTF8, "application/json");

                // response.Result.IsSuccessStatusCode == true and no errors
                var response = await client.GetAsync(URL);
                if ((int)response.StatusCode != (int)HttpStatusCode.OK)
                {
                    var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "Oops!!!" };
                    throw new HttpResponseException(msg.Content.ToString());
                }
                //response.Wait();
                return response;
            }
        }

        public static async Task<HttpResponseMessage> POSTAPITSG(string URL, string JsonModel, string Token = "", string APIKey = "")
        {
            using (var client = new HttpClient())
            {
                //string url = APIURL.BaseURL + URL;
                //string url = URLPORTServices.GetURL(URLPORT.Login) + URL;
                client.BaseAddress = new Uri(URL);
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Token);
                client.DefaultRequestHeaders.Add("APIKEY", APIKey);
                var content = new StringContent(JsonModel, Encoding.UTF8, "application/json");

                // response.Result.IsSuccessStatusCode == true and no errors
                var response = await client.PostAsync(URL, content);


                //response.Wait();

                if ((int)response.StatusCode != (int)HttpStatusCode.OK)
                {
                    var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "Oops!!!" };
                    throw new HttpResponseException(msg.Content.ToString());
                }

                return response;
            }
        }



        public static string PostMultipartFormData(string url, string filePath, Dictionary<string, string> formData, string header = null)
        {
            try
            {
                string boundary = "---------------------------" + DateTime.Now.Ticks.ToString("x");
                byte[] boundaryBytes = Encoding.ASCII.GetBytes("\r\n--" + boundary + "\r\n");
                byte[] trailer = Encoding.ASCII.GetBytes("\r\n--" + boundary + "--\r\n");

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "POST";
                request.ContentType = "multipart/form-data;" + boundary;
                request.KeepAlive = true;
                // Add custom headers
                if (!string.IsNullOrEmpty(header))
                {
                    foreach (var item in header.Split(','))
                    {
                        if (item.Contains(":"))
                        {
                            var parts = item.Split(':');
                            request.Headers.Add(parts[0].Trim(), parts[1].Trim());
                        }
                    }
                }
                using (Stream requestStream = request.GetRequestStream())
                {
                    // Add form fields
                    if (formData != null)
                    {
                        foreach (string key in formData.Keys)
                        {
                            requestStream.Write(boundaryBytes, 0, boundaryBytes.Length);
                            string formItem = $"Content-Disposition: form-data; name=\"{key}\"\r\n\r\n{formData[key]}";
                            byte[] formItemBytes = Encoding.UTF8.GetBytes(formItem);
                            requestStream.Write(formItemBytes, 0, formItemBytes.Length);
                        }
                    }
                    // Add file content
                    if (!string.IsNullOrEmpty(filePath) && File.Exists(filePath))
                    {
                        requestStream.Write(boundaryBytes, 0, boundaryBytes.Length);
                        string fileHeader = $"Content-Disposition: form-data; name=\"file\"; filename=\"{Path.GetFileName(filePath)}\"\r\nContent-Type: application/octet-stream\r\n\r\n";
                        byte[] fileHeaderBytes = Encoding.UTF8.GetBytes(fileHeader);
                        requestStream.Write(fileHeaderBytes, 0, fileHeaderBytes.Length);
                        using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                        {
                            fileStream.CopyTo(requestStream);
                        }
                    }
                    requestStream.Write(trailer, 0, trailer.Length);
                }
                using (var response = (HttpWebResponse)request.GetResponse())
                using (var responseStream = response.GetResponseStream())
                using (var reader = new StreamReader(responseStream))
                {
                    return reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static async Task<HttpResponseMessage> GetAPITSG(string URL, string JsonModel, string Token = "", string APIKey = "")
        {
            using (var client = new HttpClient())
            {
                // string url = APIURL.BaseURL + URL;
                // string url = URLPORTServices.GetURL(URLPORT.Login) + URL;
                client.BaseAddress = new Uri(URL);
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Token);
                client.DefaultRequestHeaders.Add("APIKEY", APIKey);
                client.Timeout = new TimeSpan(0, 0, 300);
                var content = new StringContent(JsonModel ?? "", Encoding.UTF8, "application/json");

                // response.Result.IsSuccessStatusCode == true and no errors
                var response = await client.GetAsync(URL);
                if ((int)response.StatusCode != (int)HttpStatusCode.OK)
                {
                    var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "Oops!!!" };
                    throw new HttpResponseException(msg.Content.ToString());
                }
                //response.Wait();
                return response;
            }
        }
        public static async Task<HttpResponseMessage> GetTnTAPI(string URL, string JsonModel, string Token)
        {
            using (var client = new HttpClient())
            {
                string url = URL;
                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Token);
                var content = new StringContent(JsonModel ?? "", Encoding.UTF8, "application/json");

                // response.Result.IsSuccessStatusCode == true and no errors
                var response = await client.GetAsync(url);
                if ((int)response.StatusCode != (int)HttpStatusCode.OK)
                {
                    var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "Oops!!!" };
                    throw new HttpResponseException(msg.Content.ToString());
                }
                //response.Wait();
                return response;
            }
        }
        public static Task<HttpResponseMessage> POSTSynchronousAPI(string URL, string JsonModel, string Token)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(URL);
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Token);
                var content = new StringContent(JsonModel, Encoding.UTF8, "application/json");

                // response.Result.IsSuccessStatusCode == true and no errors
                var response = client.PostAsync(URL, content);
                response.Wait();
                return response;
            }
        }


        /// <summary>
        ///Api calling method for get operation
        /// </summary>
        /// <param name="URL"></param>
        /// <param name="jsonModel"></param>
        /// <param name="userId"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        public static async Task<HttpResponseMessage> CallHologramGetAPI(string URL, string jsonModel,
                                                string userId = "", string userName = "")
        {
            string TNTToken = string.Empty;
            IConfiguration configuration = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            TNTToken = await JwtToken.CreateTNTJwtToken("HologramApiURL", userId, userName, userId,
               "JwtTNT", configuration);
            using (var client = new HttpClient())
            {
                string url = URLPORTServices.GetURL(URLPORT.HologramApiBaseURL) + URL;
                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.Add("Authorization", TNTToken);

                var content = new StringContent(jsonModel, Encoding.UTF8, "application/json");

                // response.Result.IsSuccessStatusCode == true and no errors
                var response = await client.GetAsync(url);
                //response.Wait();
                return response;
            }
        }
        /// <summary>
        /// Api calling method for post operation
        /// </summary>
        /// <param name="URL"></param>
        /// <param name="JsonModel"></param>
        /// <param name="userId"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        public static async Task<HttpResponseMessage> CallHologramPostAPI(string URL, string JsonModel,
                                                string userId, string userName)
        {
            string TNTToken = string.Empty;
            IConfiguration configuration = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            TNTToken = await JwtToken.CreateTNTJwtToken("HologramApiURL", userId, userName, userId,
               "JwtTNT", configuration);
            using (var client = new HttpClient())
            {
                string url = URLPORTServices.GetURL(URLPORT.HologramApiBaseURL) + URL;
                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.Add("Authorization", TNTToken);
                var content = new StringContent(JsonModel, Encoding.UTF8, "application/json");

                // response.Result.IsSuccessStatusCode == true and no errors
                var response = await client.PostAsync(url, content);
                //response.Wait();
                return response;
            }
        }
        /// <summary>
        /// Api calling method for put operation
        /// </summary>
        /// <param name="URL"></param>
        /// <param name="JsonModel"></param>
        /// <param name="userId"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        public static async Task<HttpResponseMessage> CallHologramPutAPI(string URL, string JsonModel,
                                                string userId, string userName)
        {
            string TNTToken = string.Empty;
            IConfiguration configuration = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            TNTToken = await JwtToken.CreateTNTJwtToken("HologramApiURL", userId, userName, userId,
               "JwtTNT", configuration);
            using (var client = new HttpClient())
            {
                string url = URLPORTServices.GetURL(URLPORT.HologramApiBaseURL) + URL;
                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.Add("Authorization", TNTToken);
                var content = new StringContent(JsonModel, Encoding.UTF8, "application/json");

                // response.Result.IsSuccessStatusCode == true and no errors
                var response = await client.PutAsync(url, content);
                //response.Wait();
                return response;
            }
        }


        public static async Task<HttpResponseMessage> POSTFORMDATATSG(string URL, string JsonModel, string Token = "", string APIKey = "", IFormFile formFile = null)
        {
            using (var client = new HttpClient())
            {

                client.BaseAddress = new Uri(URL);
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Token);
                client.DefaultRequestHeaders.Add("APIKEY", APIKey);
                var jsonObj = JObject.Parse(JsonModel);
                //var model = jsonObj["ITModel"];
                var formData = new MultipartFormDataContent();

                // Add all non-file fields
                foreach (var prop in jsonObj.Properties())
                {
                    if (prop.Name != "formFile") // skip file
                    {
                        formData.Add(new StringContent(prop.Value?.ToString() ?? ""), prop.Name);
                    }
                }

                // Handle the file from formFile object 

                if (formFile != null && formFile.Length > 0)
                {
                    var ms = new MemoryStream();

                    await formFile.CopyToAsync(ms);
                    ms.Position = 0;
                    var fileContent = new StreamContent(ms);
                    fileContent.Headers.ContentType = new MediaTypeHeaderValue(formFile.ContentType ?? "application/octet-stream");
                    //fileContent.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");//application/octet-stream

                    formData.Add(fileContent, "formFile", formFile.FileName);

                }


                //var modell = JsonConvert.DeserializeObject<RegisterViewModel>(JsonModel);
                //var fileName = Path.GetFileName(modell.ITModel.formFile.FileName);
                //if (fileName != null && fileName.Length > 0){
                //    string uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");
                //    if (!Directory.Exists(uploadPath))
                //        Directory.CreateDirectory(uploadPath);
                //    string filePath = Path.Combine(uploadPath, fileName);
                //var fileObj = model["formFileName"];


                //if (File.Exists(filePath))
                //{
                //    using var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                //    var fileContent = new StreamContent(stream);
                //    fileContent.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
                //    formData.Add(fileContent, "formFile", fileName);
                //}
                //else
                //{
                //    Console.WriteLine("File not found at: " + filePath);
                //}

                // Call API
                var response = await client.PostAsync(URL, formData);
                var result = await response.Content.ReadAsStringAsync();
                Console.WriteLine("Status" + response.StatusCode);
                Console.WriteLine("Response" + result);


                //response.Wait();

                if ((int)response.StatusCode != (int)HttpStatusCode.OK)
                {
                    var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "Oops!!!" };
                    throw new HttpResponseException(msg.Content.ToString());
                }

                return response;
            }
        }

        public static async Task<HttpResponseMessage> POSTFORMDATATSGItem(string URL, string JsonModel, string Token = "", string APIKey = "", List<IFormFile> formFile = null)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(URL);
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Token);
                client.DefaultRequestHeaders.Add("APIKEY", APIKey);

                var jsonObj = JObject.Parse(JsonModel);
                var formData = new MultipartFormDataContent();

                // Add all non-file fields
                foreach (var prop in jsonObj.Properties())
                {
                    if (prop.Name == "formFile")
                    {
                        // Skip formFile key in JSON because actual file comes from formFile param
                        continue;
                    }

                    if (prop.Name == "TenderItemDetailsRaw")
                    {
                        if (prop.Value != null && !string.IsNullOrWhiteSpace(prop.Value.ToString()) && prop.Value.ToString() != "")
                        {
                            // Parse the string value of TenderItemDetailsRaw into a JArray
                            var tenderItemDetails = JArray.Parse(prop.Value.ToString());
                            // Add the parsed JArray as a JSON string to the form data
                            formData.Add(new StringContent(tenderItemDetails.ToString(Formatting.None), Encoding.UTF8, "application/json"), prop.Name);
                        }
                    }
                    else if (prop.Name == "TenderItemDetailsOutRaw")
                    {
                        if (prop.Value != null && !string.IsNullOrWhiteSpace(prop.Value.ToString()) && prop.Value.ToString() != "")
                        {
                            // Parse the string value of TenderItemDetailsRaw into a JArray
                            var tenderItemDetails = JArray.Parse(prop.Value.ToString());
                            // Add the parsed JArray as a JSON string to the form data
                            formData.Add(new StringContent(tenderItemDetails.ToString(Formatting.None), Encoding.UTF8, "application/json"), prop.Name);
                        }
                    }
                    else if (prop.Name == "Files")
                    {
                        if (prop.Value != null && !string.IsNullOrWhiteSpace(prop.Value.ToString()) && prop.Value.ToString() != "")
                        {
                            // Parse the string value of TenderItemDetailsRaw into a JArray
                            var tenderItemDetails = JArray.Parse(prop.Value.ToString());
                            // Add the parsed JArray as a JSON string to the form data
                            formData.Add(new StringContent(tenderItemDetails.ToString(Formatting.None), Encoding.UTF8, "application/json"), prop.Name);
                        }
                    }

                    else
                    {
                        // Add other properties as strings
                        formData.Add(new StringContent(prop.Value?.ToString() ?? ""), prop.Name);
                    }
                }

                // Add file content if provided
                //if (formFile != null && formFile.Length > 0)
                //{
                if (formFile != null && formFile.Count > 0)
                {
                    foreach (var file in formFile)
                    {
                        if (file.Length > 0)
                        {
                            //var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", file.FileName);
                            //using (var stream = new FileStream(filePath, FileMode.Create))
                            //{
                            //    await file.CopyToAsync(stream);
                            //}
                            var ms = new MemoryStream();
                            await file.CopyToAsync(ms);
                            ms.Position = 0;
                            var fileContent = new StreamContent(ms);
                            fileContent.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType ?? "application/octet-stream");

                            formData.Add(fileContent, "formFile", file.FileName);
                        }
                    }
                    //}


                }

                var response = await client.PostAsync(URL, formData);
                var result = await response.Content.ReadAsStringAsync();
                Console.WriteLine("Status: " + response.StatusCode);
                Console.WriteLine("Response: " + result);

                if (response.StatusCode != HttpStatusCode.OK)
                {
                    var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "Oops!!!" };
                    throw new HttpRequestException(msg.ReasonPhrase);
                }

                return response;
            }
        }

        public static async Task<HttpResponseMessage> POSTFORMDATATSGItemWPS(string URL, string JsonModel, string Token = "", string APIKey = "", List<IFormFile> formFiles = null)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(URL);
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Token);
                client.DefaultRequestHeaders.Add("APIKEY", APIKey);

                var jsonObj = JObject.Parse(JsonModel);
                var formData = new MultipartFormDataContent();

                // Add all non-file fields
                foreach (var prop in jsonObj.Properties())
                {


                    if (prop.Name == "WPSD")
                    {
                        // Parse the string value of TenderItemDetailsRaw into a JArray
                        var EmdDetailsDDetails = JArray.Parse(prop.Value.ToString());
                        // Add the parsed JArray as a JSON string to the form data
                        formData.Add(new StringContent(EmdDetailsDDetails.ToString(Formatting.None), Encoding.UTF8, "application/json"), prop.Name);
                    }
                    else
                    {
                        // Add other properties as strings
                        formData.Add(new StringContent(prop.Value?.ToString() ?? ""), prop.Name);
                    }
                }

                // Add file content if provided
                if (formFiles != null && formFiles.Any(f => f.Length > 0))
                {
                    foreach (var file in formFiles)
                    {
                        var ms = new MemoryStream();
                        await file.CopyToAsync(ms);
                        ms.Position = 0;
                        var fileContent = new StreamContent(ms);
                        fileContent.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType ?? "application/octet-stream");

                        formData.Add(fileContent, "formFile", file.FileName);

                    }
                }

                var response = await client.PostAsync(URL, formData);
                var result = await response.Content.ReadAsStringAsync();
                Console.WriteLine("Status: " + response.StatusCode);
                Console.WriteLine("Response: " + result);

                if (response.StatusCode != HttpStatusCode.OK)
                {
                    var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "Oops!!!" };
                    throw new HttpRequestException(msg.ReasonPhrase);
                }

                return response;
            }
        }



        //public static async Task<HttpResponseMessage> CallSSOAPI(string URL, string JsonModel)
        //{
        //    using (var client = new HttpClient())
        //    {
        //        string url = SSOAPIURL.BaseURL + URL;
        //        client.BaseAddress = new Uri(url);
        //        var content = new StringContent(JsonModel, Encoding.UTF8, "application/json");

        //        // response.Result.IsSuccessStatusCode == true and no errors
        //        var response = await client.PostAsync(url, content);
        //        //response.Wait();
        //        return response;
        //    }
        //}
        //public static async Task<HttpResponseMessage> CallGetSSOAPI(string URL, string JsonModel)
        //{
        //    using (var client = new HttpClient())
        //    {
        //        string url = SSOAPIURL.BaseURL + URL + "/" + JsonModel;
        //        client.BaseAddress = new Uri(url);
        //        // var content = new StringContent(JsonModel, Encoding.UTF8, "application/json");

        //        // response.Result.IsSuccessStatusCode == true and no errors
        //        var response = await client.GetAsync(url);
        //        //response.Wait();
        //        return response;
        //    }
        //}

    }
}
