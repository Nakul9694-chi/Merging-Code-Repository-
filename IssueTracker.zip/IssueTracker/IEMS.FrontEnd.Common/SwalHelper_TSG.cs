﻿using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEMS.FrontEnd.Common.Common
{
    public static class SwalHelper_TSG
    {
        public static void SetSwalAlert(ITempDataDictionary tempData, string title, string text, string icon = "info")
        {
            tempData["SwalTitle"] = title;
            tempData["SwalText"] = text;
            tempData["SwalIcon"] = icon; // "success", "error", "warning", "info", "question"
        }
    }
}
