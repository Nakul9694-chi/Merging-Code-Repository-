﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace IEMS.FrontEnd.Common.Common
{
    public class ModuleApiKeyTSG
    {
        public readonly string PurchaseApiKey = "@#$%^&*((*&6545YHJJN%^&*";
        public readonly string ProductionTSGApiKey = "pwqueqodcbwexnxwqidbdndn";
        public readonly string IssueTrackerApiKey = "abcdefghijklmnoprtwya";
        public readonly string userMgmtApiKey = "dasdfdsfsfdfermlnuuewedsd";
        public readonly string UserManagementTSGApiKey = "dasdfdsfsfdfermlnuuewedsd";
    }
    public static class TSGApiConfig
    {
        public static readonly string GetTenderLOAList = "GetTenderLOAList";
        public static readonly string GetTenderListForLOA = "GetTenderListForLOA";
        public static readonly string GetTenderSelectedBidderListForLOA = "GetTenderSelectedBidderListForLOA";
        public static readonly string GetGSMFinancialYear = "GetGSMFinancialYear";
        public static readonly string GetTenderSupplierItemForLOA = "GetTenderSupplierItemForLOA";
        public static readonly string GetTenderItemPoQtyLOA = "GetTenderItemPoQtyLOA";
        public static readonly string GetTenderLOADetails = "GetTenderLOADetails";
        public static readonly string SaveUpdateTenderLOADetail = "SaveUpdateTenderLOADetail";
        public static readonly string GetPOList = "GetPOList";
        public static readonly string GetPoByPoRefNo = "GetPoByPoRefNo";
        public static readonly string GetTenderListForPO = "GetTenderListForPO";
        public static readonly string GetTenderItemDetailForPO = "GetTenderItemDetailForPO";
        public static readonly string GetSubGroupForPO = "GetSubGroupForPO";
        public static readonly string GetSupplierForPO = "GetSupplierForPO";
        public static readonly string GetSupplierWisePendingItemForPO = "GetSupplierWisePendingItemForPO";
        public static readonly string SaveTenderPODetails = "SaveTenderPODetails";
        public static readonly string GetGSMAPOList = "GetGSMAPOList";
        public static readonly string ApoDetails = "ApoDetails";
        public static readonly string GetGSMTenderPoForAPO = "GetGSMTenderPoForAPO";
        public static readonly string GetGSMSuppliersByTenderIdForAPO = "GetGSMSuppliersByTenderIdForAPO";
        public static readonly string GetGSMPoBySupplierAndTenderForAPO = "GetGSMPoBySupplierAndTenderForAPO";
        public static readonly string GetDetailByPoRefNoForApo = "GetDetailByPoRefNoForApo";
        public static readonly string GetGSMPoItemsByGroupAndPoForAPO = "GetGSMPoItemsByGroupAndPoForAPO";
        public static readonly string SaveApoData = "SaveApoData";
        public static readonly string SaveTenderProcess = "SaveTenderProcess";
        public static readonly string GETGRIEVANCEREGISTRATION = "GETGRIEVANCEREGISTRATION";
        public static readonly string UpdateStatusGrievance = "UPDATESTATUSGRIEVANCE";
        public static readonly string GetGrievanceUserAction = "GETGRIEVANCEUSERACTION";
        public static readonly string GetGrievanceCount = "GETGRIEVANCECOUNT";
        public static readonly string GetGrievanceCountDetail = "GETGRIEVANCECOUNTDETAILS";
        public static readonly string GetGrievanceWorkFlowAction = "GETGRIEVANCEWORKFLOWACTION";
        public static readonly string GetUserMGMasterDataDropDown = "GetUserMGMasterDataDropDown";
        public static readonly string UpdateTenderProcess = "UpdateTenderProcess";
        public static readonly string GetAllTenderProcess = "GetTenderProcess";
        public static readonly string GetAllTenderProcessList = "GetAllTenderProcessList";
        public static readonly string SaveTenderItemDetail = "SaveTenderItemDetail";
        public static readonly string UpdateTenderItemDetail = "UpdateTenderItemDetail";

        public static readonly string ReportTenderEMDDetail = "ReportTenderEMDDetail";
        public static readonly string ReportAPODetails = "ReportAPODetails";
        public static readonly string GetGSMDropDownMaster = "GetGSMDropDownMaster";
       

        public static readonly string GetTenderWPSList = "GetTenderWPSList";
        public static readonly string GetTenderForWPS = "GetTenderForWPS";
        public static readonly string GetBidderForWPS = "GetBidderForWPS";
        public static readonly string GetEMDCalForWPS = "GetEMDCalForWPS";
        public static readonly string GetLOADetailForWPS = "GetLOADetailForWPS";
        public static readonly string GetGSMBankMaster = "GetGSMBankMaster";       
        public static readonly string SaveUpdateTenderWPS = "SaveUpdateTenderWPS";



        #region Production Config
        public static readonly string GetAllGrain = "GetAllGrain";
        public static readonly string GetUseMasterDataDropDown = "GetUserMGMasterDataDropDown";
        public static readonly string GetAllPlantDetails = "GetAllPlant";
        public static readonly string GetAllPlantTypeDetails = "GetAllPlantType";
        public static readonly string UpdatePlantMasterStatus = "UpdatePlantMasterActiveStatus";
        public static readonly string UpdatePlanTypeActiveStatus = "UpdatePlantTypeMasterActiveStatus";
        public static readonly string GetAllProcessTemplateDetails = "GetAllProcessTemplate";
        public static readonly string SaveProcessTemplateMaster = "SaveProcessTemplateMaster";
        public static readonly string UpdateProcessTemplateMaster = "UpdateProcessTemplateMaster";
        public static readonly string UpdateTemplateMasterStatus = "UpdateProcessTemplateMasterActiveStatus";
        public static readonly string GetAllProcessTemplateStepDetails = "GetAllProcessTemplateStep";
        public static readonly string SaveProcessTemplateStepMaster = "SaveProcessTemplateStepMaster";
        public static readonly string UpdateProcessTemplateStepMaster = "UpdateProcessTemplateStepMaster";
        public static readonly string UpdateTemplateStepActiveStatus = "UpdateProcessTemplateStepMasterActiveStatus";
        public static readonly string SavePlantDataMaster = "SavePlantMaster";
        public static readonly string SavePlantTypeDataMaster = "SavePlantTypeMaster";
        public static readonly string UpdatePlantTypeDataMaster = "UpdatePlantTypeMaster";
        public static readonly string UpdatePlantMaster = "UpdatePlantMaster";
        public static readonly string GetThresholdRules = "GetAllThresholdRules";
        public static readonly string UpdateThresholdActiveStatus = "UpdateThresholdRulesMasterActiveStatus";
        public static readonly string SaveThresholdRulesMaster = "SaveThresholdRulesMaster";
        public static readonly string UpdateThresholdRulesMaster = "UpdateThresholdRulesMaster";
        public static readonly string GetAllProductionBatchs = "GetAllProductionBatchs";
        public static readonly string SaveProductionBatchs = "SaveProductionBatchs";
        public static readonly string UpdateBatchsMasterActiveStatus = "UpdateProductionBatchsActiveStatus";
        #endregion Production Config


        //Issue Trackecr API
        //public static readonly string GetUserMGMasterDataDropDown = "GetUserMGMasterDataDropDown";
        public static readonly string GETGRIEVANCEWORKFLOWACTION = "GETGRIEVANCEWORKFLOWACTION";
        public static readonly string SAVEGRIEVANCEREGISTRATION = "SAVEGRIEVANCEREGISTRATION";
        public static readonly string UPDATEGRIEVANCEREGISTRATION = "UPDATEGRIEVANCEREGISTRATION";
        public static readonly string SSOGetUserDetail = "SSOGetUserDetail?SSOID={0}";

        public static readonly string GetTenderProcessById = "GetTenderProcessById";
        public static readonly string GetTenderProcessItemListById = "GetTenderProcessItemListById";
        public static readonly string GetTenderProcessBidderById = "GetTenderProcessBidderById";
        public static readonly string GetTenderSelectionStatus = "GetTenderSelectionStatus";
        public static readonly string IEMSSendSMS = "IEMSSendSMS";
        public static readonly string UpdateTenderBidderSelectionStatus = "UpdateTenderProcessSupplierSelectionStatus";
        public static readonly string GetItemGroupForDrp = "GetItemGroupForDrp";
        public static readonly string GetItemSubGroupForDrp = "GetItemSubGroupForDrp";
        public static readonly string GetAllRCForDrp = "GetAllRCForDrp";
        public static readonly string GetAllItemBySubGrpForDrp = "GetAllItemBySubGrpForDrp";
        public static readonly string GetTenderItemDetail = "GetTenderItemDetail";
        public static readonly string GetGSMTenderItemFile = "GetGSMTenderItemFile";
        public static readonly string GetAllFeeType = "GetAllFeeType";
        public static readonly string GetAllPayMode = "GetAllPayMode";
        public static readonly string GetAllSupplier = "GetAllSupplier";
        public static readonly string GetAllTenderBidderDetail = "GetAllTenderBidderDetail";
        public static readonly string SaveTenderBidderDetail = "SaveTenderBidderDetail";
    }

}
