﻿using Microsoft.Extensions.Configuration;

namespace IEMS.FrontEnd.Common
{
    public enum URLPORT
    {
        Login,
        DepoEntryGate,
        OrderForSupply,
        OnlinePermitGenerate,
        TNT,
        SpiritImport,
        SSOAPIURL,
        SSOBACKRL,
        DepotDamage,
        DepotSale,
        DepotDrainOut,
        TNTApiForSummary,
        DepoSampling,
        StockManagement,
        DepotDamageTNTURL,
        SupplierInvoiceTNTURL,
        TNTApiForGetCaseSummary,
        TNTApiForGetBottleStatus,
        TNTApiForUpdateBottleStatus,
        TNTApiForDrainSummary,
        BrandLabelApproval,
        TNTApiForSamplingSummary,
        TNTApiForUpdateBottleStatusForSampling,
        DepoSaleTNT,
        SpiritExport,
        TNTApiForReSamplingSummary,
        CaneProduction,
        MasterModule,
        SugarSale,
        Esign,
        PublicService,
        Auction,
        HologramApiBaseURL,
        PharmacyReg,
        ManufactureUnitRenewal,
        CompositeLicense,
        BrandOwnerShip,
        DenaturedSpritBalanceOpening,
        LineProduction,
        VatCalibrationProduction,
        VatEntryModule,
        mfgunitrenewal,
        DailyProduction,
        ProductionModule,
        ProductionMaster,
        MfgProduction,
        Purchase,
        ItemDefiniton,
        RefundAdjustment,
        RateApproval,
        EntityApi,
        printLog,
        FMSMasters,
        LocationApi,
		GST,
		IEMS_Web,
        IssueTracker_TSG,
        RSGSMPurchase,
        Purchase_TSG,
        Production_TSG,
        UserManagement_TSG,
        MessageBus_TSG

    }
    public enum TSGAPIKEY
    {
        Purchase,
        IssueTracker_TSG,
        UserManagement_TSG,
        MessageBus_TSG,
        Production_TSG
    }

    public static class URLPORTServices
    {
        public static IConfiguration getProperties = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: false, reloadOnChange: false).Build();

        public static string GetURL(URLPORT obj)
        {
            string URL = null;
            switch (obj)
            {
                case URLPORT.Login:
                    URL = getProperties.GetSection("MasterAPIURL").Value;
                    break;
                case URLPORT.DepoEntryGate:
                    URL = getProperties.GetSection("DepoGateEntryURL").Value;
                    break;
                case URLPORT.OrderForSupply:
                    URL = getProperties.GetSection("OrderForSupplyURL").Value;
                    break;
                case URLPORT.OnlinePermitGenerate:
                    URL = getProperties.GetSection("OnlinePermitGenerateURL").Value;
                    break;
                case URLPORT.TNT:
                    URL = getProperties.GetSection("OnlinePermitGenerateURL").Value;
                    break;
                case URLPORT.SpiritImport:
                    URL = getProperties.GetSection("MasterAPIURL").Value;
                    break;
                case URLPORT.SSOAPIURL:
                    URL = getProperties.GetSection("SSOAPIURL").Value;
                    break;
                case URLPORT.SSOBACKRL:
                    URL = getProperties.GetSection("SSOBACKRL").Value;
                    break;
                case URLPORT.DepotSale:
                    URL = getProperties.GetSection("DepotSaleURL").Value;
                    break;
                case URLPORT.DepotDamage:
                    URL = getProperties.GetSection("DepotDamageURL").Value;
                    break;
                case URLPORT.DepotDrainOut:
                    URL = getProperties.GetSection("DepotDrainOut").Value;
                    break;
                case URLPORT.TNTApiForSummary:
                    URL = getProperties.GetSection("TNTApiForSummary").Value;
                    break;
                case URLPORT.DepoSampling:
                    URL = getProperties.GetSection("DepoSampling").Value;
                    break;
                case URLPORT.StockManagement:
                    URL = getProperties.GetSection("StockManagement").Value;
                    break;
                case URLPORT.DepotDamageTNTURL:
                    URL = getProperties.GetSection("DepotDamageTNTURL").Value;
                    break;
                case URLPORT.SupplierInvoiceTNTURL:
                    URL = getProperties.GetSection("SupplierInvoiceTNTURL").Value;
                    break;
                case URLPORT.TNTApiForGetCaseSummary:
                    URL = getProperties.GetSection("TNTApiForGetCaseSummary").Value;
                    break;
                case URLPORT.TNTApiForGetBottleStatus:
                    URL = getProperties.GetSection("TNTApiForGetBottleStatus").Value;
                    break;
                case URLPORT.TNTApiForUpdateBottleStatus:
                    URL = getProperties.GetSection("TNTApiForUpdateBottleStatus").Value;
                    break;
                case URLPORT.TNTApiForDrainSummary:
                    URL = getProperties.GetSection("TNTApiForDrainSummary").Value;
                    break;
                case URLPORT.BrandLabelApproval:
                    URL = getProperties.GetSection("BrandLabelApprovalURL").Value;
                    break;
                case URLPORT.TNTApiForSamplingSummary:
                    URL = getProperties.GetSection("TNTApiForSamplingSummary").Value;
                    break;
                case URLPORT.TNTApiForReSamplingSummary:
                    URL = getProperties.GetSection("TNTApiForReSamplingSummary").Value;
                    break;
                case URLPORT.TNTApiForUpdateBottleStatusForSampling:
                    URL = getProperties.GetSection("TNTApiForUpdateBottleStatusForSampling").Value;
                    break;
                case URLPORT.DepoSaleTNT:
                    URL = getProperties.GetSection("DepoSaleTNTURL").Value;
                    break;
                case URLPORT.SpiritExport:
                    URL = getProperties.GetSection("MasterAPIURL").Value;
                    break;
                case URLPORT.CaneProduction:
                    URL = getProperties.GetSection("CaneProductionAPI").Value;
                    break;
                case URLPORT.MasterModule:
                    URL = getProperties.GetSection("MasterAPIURLTest").Value;
                    break;
                case URLPORT.Esign:
                    URL = getProperties.GetSection("MasterAPIURL").Value;
                    break;
                case URLPORT.PublicService:
                    URL = getProperties.GetSection("MasterAPIURL").Value;
                    break;
                case URLPORT.Auction:
                    URL = getProperties.GetSection("AuctionURL").Value;
                    break;
                case URLPORT.HologramApiBaseURL:
                    URL = getProperties.GetSection("HologramApiBaseURL").Value;
                    break;
                case URLPORT.PharmacyReg:
                    URL = getProperties.GetSection("PharmacyRegURL").Value;
                    break;
                case URLPORT.ManufactureUnitRenewal:
                    URL = getProperties.GetSection("ManufactureUnitRenewalApiUrl").Value;
                    break;
                case URLPORT.CompositeLicense:
                    URL = getProperties.GetSection("CompositeLicenseURL").Value;
                    break;
                case URLPORT.BrandOwnerShip:
                    URL = getProperties.GetSection("MasterAPIURL").Value;
                    break;
                case URLPORT.mfgunitrenewal:
                    URL = getProperties.GetSection("MasterAPIURL").Value;
                    break;
                case URLPORT.DailyProduction:
                    URL = getProperties.GetSection("Login").Value;
                    break;
                case URLPORT.ProductionModule:
                    URL = getProperties.GetSection("ProductionAPIUrl").Value;
                    break;
                case URLPORT.ProductionMaster:
                    URL = getProperties.GetSection("ProductionMasterAPIUrl").Value;
                    break;
                case URLPORT.MfgProduction:
                    URL = getProperties.GetSection("ProductionAPIURL").Value;
                    break;
                case URLPORT.Purchase:
                    URL = getProperties.GetSection("PurchaseAPIURL").Value;
                    break;
                case URLPORT.ItemDefiniton:
                    URL = getProperties.GetSection("ItemDefinitonAPIURL").Value;
                    break;
                case URLPORT.RefundAdjustment:
                    URL = getProperties.GetSection("RefundAdjustmentAPIURL").Value;
                    break;
                case URLPORT.RateApproval:
                    URL = getProperties.GetSection("RateApproval").Value;
                    break;
                case URLPORT.EntityApi:
                    URL = getProperties.GetSection("EntityRSBLAPI").Value;
                    break;
                case URLPORT.printLog:
                    URL = getProperties.GetSection("PrintLog").Value;
                    break;
                case URLPORT.FMSMasters:
                    URL = getProperties.GetSection("FMSApiUrl").Value;
                    break;

                case URLPORT.LocationApi:
                    URL = getProperties.GetSection("LocationApi").Value;
                    break;
                case URLPORT.GST:
                    URL = getProperties.GetSection("GSTApi").Value;
                    break;
                case URLPORT.IEMS_Web:
                    URL = getProperties.GetSection("IEMS_Web").Value;
                    break;
                case URLPORT.RSGSMPurchase:
                    URL = getProperties.GetSection("RSGSMPurchase").Value;
                    break;
                case URLPORT.Purchase_TSG:
                    URL = getProperties.GetSection("PurchaseTSGAPIURL").Value;
                    break;
                case URLPORT.IssueTracker_TSG:
                    URL = getProperties.GetSection("IssueTrackerAPIURL").Value;
                    break;
                case URLPORT.UserManagement_TSG:
                    URL = getProperties.GetSection("UserManagementAPIURL").Value;
                    break;
                case URLPORT.Production_TSG:
                    URL = getProperties.GetSection("ProductionTSGAPIURL").Value;
                    break;
                case URLPORT.MessageBus_TSG:
                    URL = getProperties.GetSection("MessageBusTSGAPIURL").Value;
                    break;
            }
            return URL;
        }
        public static string GetAPIKey(TSGAPIKEY obj)
        {
            string APIKEY = null;
            switch (obj)
            {
                case TSGAPIKEY.Purchase:
                    APIKEY = getProperties.GetSection("PurchaseAPIKEY").Value;
                    break;
                case TSGAPIKEY.IssueTracker_TSG:
                    APIKEY = getProperties.GetSection("IssueTrackerAPIKEY").Value;
                    break;
                case TSGAPIKEY.UserManagement_TSG:
                    APIKEY = getProperties.GetSection("UserManagementAPIKEY").Value;
                    break;
                case TSGAPIKEY.MessageBus_TSG:
                    APIKEY = getProperties.GetSection("MessageBusAPIKEY").Value;
                    break;
                case TSGAPIKEY.Production_TSG:
                    APIKEY = getProperties.GetSection("ProductionTSGApiKey").Value;
                    break;
            }
            return APIKEY;
        }
    }
    public enum ESIGNBOCODE
    {
        PharmacyReg,
        brandandlabel,
        brandandlabelotherstate,

    }

    public static class ESIGNBOCODEServices
    {
        public static int GetCode(ESIGNBOCODE obj)
        {
            int BO_ID = 0;
            switch (obj)
            {
                case ESIGNBOCODE.PharmacyReg:
                    BO_ID = 165;
                    break;
                case ESIGNBOCODE.brandandlabel:
                    BO_ID = 110;
                    break;
                case ESIGNBOCODE.brandandlabelotherstate:
                    BO_ID = 435;
                    break;

            }
            return BO_ID;
        }
    }
}
