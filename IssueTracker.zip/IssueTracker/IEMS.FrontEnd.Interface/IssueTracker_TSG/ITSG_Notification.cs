﻿using IEMS.FrontEnd.Models.Common_TSG;
using IEMS.FrontEnd.Models.TSG_Notification.Notification.Payload;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEMS.FrontEnd.Interface.IssueTracker_TSG
{
    public interface ITSG_Notification
    {
        Task<ApiResponse<object>> getGrievanceRegistrationData(GrievanceDataPayload reqModel);
        Task<ApiResponse<object>> getGrievanceRegistrationListFilterData(GrievanceRegistrationPayload reqModel);
        Task<ApiResponse<object>> getUserMGMasterData(MasterDropDownInput reqModel);
        Task<ApiResponse<object>> getGrievanceWorkFlowAction(GrievanceWorkFlowPayload reqModel);
        Task<ApiResponse<object>> updateStatusGrievance(UpdateStatusGrievancePayload reqModel);
        Task<ApiResponse<object>> getGrievanceUserAction(GrievanceUserActionPayload reqModel);
        Task<ApiResponse<object>> SendSMS(SendSMSPayload reqModel);
        Task<ApiResponse<object>> getGrievanceCount(GrievanceCountPayload reqModel);
        Task<ApiResponse<object>> getGrievanceCountDetail(GrievanceCountDetailPayload reqModel);
    }
}
