﻿using IEMS.FrontEnd.Models.Common_TSG;
using IEMS.FrontEnd.Models.IssueTracker_TSG.Register;
using IEMS.FrontEnd.Models.IssueTracker_TSG.RegisterVM;
using IEMS.FrontEnd.Models.Purchase_TSG;
using IEMS.FrontEnd.Models.ResponseModel;
using IEMS.FrontEnd.Models.TSG_Notification.Notification.Payload;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEMS.FrontEnd.Interface.IssueTracker_TSG
{
    public interface IIssueTracker
    {
        //Task<ApiResponse<object>> GetDepartmentList(MasterDropDownInput formUserMGMasterData); 

        Task<MasterDropDown> GetDepartmentList(string UserID);
        
        Task<ApiResponse<object>> GetGrievanceWorkFlowAction(GrievanceWorkFlowPayload grievanceWorkFlowPayload);
        Task<ApiResponse<object>> SaveIssueTracker(IssueTrackerModel vm);
        Task<ApiResponse<object>> UpdateIssueTracker(IssueTrackerModel vm);
        Task<ApiResponse<object>> GetSSODetail(string SSOID);

    }
}
