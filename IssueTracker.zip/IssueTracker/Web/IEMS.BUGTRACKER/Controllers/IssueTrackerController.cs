﻿using DocumentFormat.OpenXml.Bibliography;
using DocumentFormat.OpenXml.EMMA;
using DocumentFormat.OpenXml.Wordprocessing;
using IEMS.FrontEnd.Common;
using IEMS.FrontEnd.Common.Common;
using IEMS.FrontEnd.Interface.IssueTracker_TSG;
using IEMS.FrontEnd.Interface.MasterModule;
using IEMS.FrontEnd.Interface.Purchase_TSG;
using IEMS.FrontEnd.Models;
using IEMS.FrontEnd.Models.Common_TSG;
using IEMS.FrontEnd.Models.IssueTracker_TSG.Register;
using IEMS.FrontEnd.Models.IssueTracker_TSG.RegisterVM;
using IEMS.FrontEnd.Models.Purchase_TSG;
using IEMS.FrontEnd.Models.RateApproval;
using IEMS.FrontEnd.Models.ResponseModel;
using IEMS.FrontEnd.Models.TSG_Notification;
using IEMS.FrontEnd.Models.TSG_Notification.Notification;
using IEMS.FrontEnd.Models.TSG_Notification.Notification.Payload;
using IEMS.FrontEnd.Services.TSG_IssueTracker;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Net.Http.Json;
using System.Reflection;
using static IEMS.FrontEnd.Models.TSG_Notification.Notification.IssuesModel;

namespace IEMS.BUGTRACKER.Areas.IssueTracker.Controllers
{
    [Area("IssueTracker")]
    public class IssueTrackerController : BaseController
    {
        SessionDetails objSession;
        private void SetSessionValue()
        {
            objSession = HttpContext.Session.GetComplexData<SessionDetails>("SessionDetails");
        }
        private readonly IIssueTracker _iIssueTracker;
        private readonly ITSG_Notification _iTSG_Notification;
        public IssueTrackerController(IIssueTracker iIssueTracker, ITSG_Notification iTSG_Notification)
        {
            _iIssueTracker = iIssueTracker;
            _iTSG_Notification = iTSG_Notification;
        }

        private static List<StatusOption> GrievanceStatus = new List<StatusOption>
        {
            new StatusOption { Id = "1", FullName = "Open" },
            new StatusOption { Id = "2", FullName = "In Progress" },
            new StatusOption { Id = "3", FullName = "Closed" }
        };

        [HttpGet]
        public async Task<ActionResult> IssueTrackerList()
        {
            List<GrievanceRegistrationData> obj = new List<GrievanceRegistrationData>();
            List<FrontEnd.Models.TSG_Notification.Notification.Payload.GrievanceWorkFlowAction> objWorkFlowAction = new List<FrontEnd.Models.TSG_Notification.Notification.Payload.GrievanceWorkFlowAction>();
            var grievanceRegistrationPayload = new GrievanceDataPayload
            {
                ACTION = "BY_SSOID",
                SSOID = "SANDEEPKUMAR641989",
                ROLE_ID = 35,
                GR_ID = 0,
                USER_ID = 0
            };
            ApiResponse<object> apiResponse = await _iTSG_Notification.getGrievanceRegistrationData(grievanceRegistrationPayload);

            if (apiResponse != null || apiResponse.Response != null)
            {
                obj = JsonConvert.DeserializeObject<List<GrievanceRegistrationData>>(JsonConvert.SerializeObject(apiResponse.Response));

            }

            var grievanceWorkFlowPayload = new GrievanceWorkFlowPayload
            {
                ACTION = "UPDATE",
                PROJECT_ID = 1,
                SOURCE_ROLE_ID = 75,
                SOURCE_STAGE_ID = 24
            };
            ApiResponse<object> apiResponse4 = await _iTSG_Notification.getGrievanceWorkFlowAction(grievanceWorkFlowPayload);
            if (apiResponse4 != null || apiResponse4.Response != null)
            {
                objWorkFlowAction = JsonConvert.DeserializeObject<List<FrontEnd.Models.TSG_Notification.Notification.Payload.GrievanceWorkFlowAction>>(JsonConvert.SerializeObject(apiResponse4.Response));
            }
            var model = new IssueViewModel
            {
                Filter = new IssueFilter(),
                Issues = obj,
                GrievanceStatus = GrievanceStatus,
                GrievanceWorkflowActions = objWorkFlowAction
            };
            return View(model);
        }

        [HttpGet]
        public async Task<ActionResult> GetIssueTrackerHistory(int issueId)
        {
            // TODO: Replace below with real data retrieval based on issueId
            List<GrievanceTrail> trailData = new List<GrievanceTrail>();
            List<GrievanceData> grvData = new List<GrievanceData>();
            var grievanceTrailPayload = new GrievanceRegistrationPayload
            {
                ACTION = "HISTORY",
                SSOID = "SANDEEPKUMAR641989",
                ROLE_ID = 35,
                GR_ID = issueId,
                USER_ID = 0,
                STATUS_ID = 0,
                FROM_DATE = "",
                TO_DATE = ""
            };

            ApiResponse<object> apiResponse = await _iTSG_Notification.getGrievanceRegistrationListFilterData(grievanceTrailPayload);

            if (apiResponse != null || apiResponse.Response != null)
            {
                trailData = JsonConvert.DeserializeObject<List<GrievanceTrail>>(JsonConvert.SerializeObject(apiResponse.Response));

            }

            var grievanceHistoryPayload = new GrievanceRegistrationPayload
            {
                ACTION = "BY_GRIEVANCE_ID",
                SSOID = "SANDEEPKUMAR641989",
                ROLE_ID = 35,
                GR_ID = issueId,
                USER_ID = 0,
                STATUS_ID = 0,
                FROM_DATE = "",
                TO_DATE = ""
            };

            ApiResponse<object> apiResponse1 = await _iTSG_Notification.getGrievanceRegistrationListFilterData(grievanceHistoryPayload);

            if (apiResponse1 != null || apiResponse1.Response != null)
            {
                grvData = JsonConvert.DeserializeObject<List<GrievanceData>>(JsonConvert.SerializeObject(apiResponse1.Response));

            }
            var model = new IssueHistory
            {
                GrievanceGetBasicDataModel = grvData,
                GrievanceTrailModel = trailData
            };

            return PartialView("_IssueTrackerHistory", model);
        }
        [HttpGet]
        public async Task<IActionResult> GetSubModuleList(int ModuleId)
        {          
            MasterDropDown resModel = new MasterDropDown();
            resModel = await _iIssueTracker.GetDepartmentList("17572");
            ViewBag.Department = resModel.List;
            return Ok(resModel.List);
        }

        [HttpGet]
        public async Task<IActionResult> Register(int? gvId = 0)
        {
            var vm = new IssueTrackerModel();

            SSOData ssoModel = new SSOData();
            ApiResponse<object> ssoResponse = await _iIssueTracker.GetSSODetail("SANDEEPKUMAR641989");
            if (ssoResponse.Status == 1 && ssoResponse.Response != null)
            {

                ssoModel = JsonConvert.DeserializeObject<SSOData>(JsonConvert.SerializeObject(ssoResponse.Response));
            }

            vm.SSOID = ssoModel.ssoid;
            vm.NAME = ssoModel.displayName;
            vm.MOBILE_NUMBER = long.Parse(ssoModel.mobile);
            vm.DESIGNATION = ssoModel.designation;

            //};

            MasterDropDown resModel = new MasterDropDown();
            resModel = await  _iIssueTracker.GetDepartmentList("17572");
            ViewBag.Department = resModel.List;

            if (gvId > 0)
            {
                // Fill for edit mode
                List<GrievanceData> grvData = new List<GrievanceData>();
                var model = new RegisterViewModel();

                var grievanceRegistrationPayload = new GrievanceDataPayload
                {
                    ACTION = "ALL",
                    SSOID = "SANDEEPKUMAR641989",
                    ROLE_ID = 35,
                    GR_ID = 0,
                    USER_ID = 207
                };
                ApiResponse<object> apiResponse = await _iTSG_Notification.getGrievanceRegistrationData(grievanceRegistrationPayload);
                if (apiResponse != null && apiResponse.Response != null)
                {

                    grvData = JsonConvert.DeserializeObject<List<GrievanceData>>(JsonConvert.SerializeObject(apiResponse.Response));


                    vm.DEPT_ID = grvData.FirstOrDefault()?.DEPT_ID ?? 0;
                    vm.MODULE_ID = grvData.FirstOrDefault()?.MODULE_ID ?? 0;
                    vm.SUB_MODULE_ID = grvData.FirstOrDefault()?.SUB_MODULE_ID ?? 0;
                    vm.DESCRIPTION = grvData.FirstOrDefault()?.DESCRIPTION ?? "";
                    vm.UPLOAD_FILES = grvData.FirstOrDefault()?.UPLOAD_FILES ?? "";
                    vm.SOURCE_STAGE_ID = grvData.FirstOrDefault()?.SOURCE_STAGE_ID ?? 0;
                    vm.AUDIT_ID = grvData.FirstOrDefault()?.AUDIT_ID ?? 0;
                    vm.GR_ID = gvId ?? 0;
                    vm.GRIEVANCE_ID = grvData.FirstOrDefault()?.GRIEVANCE_ID;
                    vm.DESTINATION_USER_ID = grvData.FirstOrDefault()?.DESTINATION_USER_ID ?? 0;

                    MasterDropDown subModule = new MasterDropDown();
                    subModule = await _iIssueTracker.GetDepartmentList("17572");
                    ViewBag.SubModule = subModule.List;
                }

            }
            else
            {


            }
            return View("Register", vm);

        }

        [HttpPost]
        [ValidateAntiForgeryToken()]
        public async Task<IActionResult> Register(IssueTrackerModel vm)
        {
            SetSessionValue();

            //if (!ModelState.IsValid)
            //{
            //return View("Register", vm);             
            //}
            if (vm.GR_ID > 0)
            {
                var grievanceWorkFlowPayload = new GrievanceWorkFlowPayload
                {
                    ACTION = "UPDATE",
                    PROJECT_ID = 1,
                    SOURCE_STAGE_ID = 6, //vm.SOURCE_STAGE_ID,
                    SOURCE_ROLE_ID = 75 //objSession.SOURCE_ROLE_ID;
                };

                List<GrievanceWorkFlowActionResponse> workflowData = new List<GrievanceWorkFlowActionResponse>();
                workflowData = await GetWorkFlow(grievanceWorkFlowPayload);

                List<GrievanceResponse> obj = new List<GrievanceResponse>();

                vm.STATUS_ID = workflowData[0].STATUS_ID;
                vm.DESTINATION_ROLE_ID = workflowData[0].DESTINATION_ROLE_ID;
                vm.SOURCE_STAGE_ID = workflowData[0].SOURCE_STAGE_ID;
                vm.DESTINATION_STAGE_ID = workflowData[0].DESTINATION_STAGE_ID;
                vm.ACTION_ID = workflowData[0].ACTION_ID;
                vm.USER_ID = 207; //objSession.UserID;                
                vm.SOURCE_ROLE_ID = 75;
                vm.MODIFIED_BY = "SANDEEPKUMAR641989";
                vm.PROJECT_ID = 1;
                vm.DEPT_ID = 2;
                vm.MODULE_ID = 64;
                vm.SUB_MODULE_ID = 41;

                ApiResponse<object> apiResponse = await _iIssueTracker.UpdateIssueTracker(vm);
                if (apiResponse != null || apiResponse.Response != null)
                {
                    obj = JsonConvert.DeserializeObject<List<GrievanceResponse>>(JsonConvert.SerializeObject(apiResponse.Response));
                    SwalHelper_TSG.SetSwalAlert(TempData, "Success", apiResponse.Message, "success");
                }

            }
            else
            {

                var grievanceWorkFlowPayload = new GrievanceWorkFlowPayload
                {
                    ACTION = "START",
                    PROJECT_ID = 1,
                    SOURCE_STAGE_ID = 0, //vm.SOURCE_STAGE_ID,
                    SOURCE_ROLE_ID = 75 //objSession.SOURCE_ROLE_ID;
                };
                List<GrievanceWorkFlowActionResponse> workflowData = new List<GrievanceWorkFlowActionResponse>();
                workflowData = await GetWorkFlow(grievanceWorkFlowPayload);

                var fileName = "";
                var filePath = "";

                if (vm.formFile != null && vm.formFile.Length > 0)
                {
                    fileName = Path.GetFileName(vm.formFile.FileName);
                    var uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");
                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);
                    filePath = Path.Combine(uploadPath, fileName);
                }
                List<GrievanceResponse> obj = new List<GrievanceResponse>();

                vm.STATUS_ID = workflowData[0].STATUS_ID;
                vm.DESTINATION_ROLE_ID = workflowData[0].DESTINATION_ROLE_ID;
                vm.SOURCE_STAGE_ID = workflowData[0].SOURCE_STAGE_ID;
                vm.DESTINATION_STAGE_ID = workflowData[0].DESTINATION_STAGE_ID;
                vm.ACTION_ID = workflowData[0].ACTION_ID;
                vm.USER_ID = 207;
                vm.DESTINATION_USER_ID = 0;
                vm.SOURCE_ROLE_ID = 75;
                vm.AUDIT_ID = 0;
                vm.CREATED_BY = "SANDEEPKUMAR641989";
                vm.PROJECT_ID = 1;

                vm.DEPT_ID = 2;
                vm.MODULE_ID = 64;
                vm.SUB_MODULE_ID = 41;
                vm.formFileName = fileName;
                vm.formFilePath = filePath;
                ApiResponse<object> apiResponse = await _iIssueTracker.SaveIssueTracker(vm);
                if (apiResponse != null || apiResponse.Response != null)
                {
                    obj = JsonConvert.DeserializeObject<List<GrievanceResponse>>(JsonConvert.SerializeObject(apiResponse.Response));
                    if (obj != null)
                    {
                        foreach (GrievanceResponse response in obj)
                        {
                            await SendSMS(response);
                        }
                    }
                    SwalHelper_TSG.SetSwalAlert(TempData, "Success", apiResponse.Message, "success");
                }
            }

            return RedirectToAction("IssueTrackerList");
        }
        public async Task<ActionResult> SendSMS(GrievanceResponse response)
        {
            var payload = new SendSMSPayload
            {
                action_ID = response.ACTION_ID,
                mobileNumber = response.MOBILE_NUMBER,
                project_ID = response.PROJECT_ID,
                templateId = response.SMSTEMPLATE_ID,
                templateSMS = response.TEMPLATEMESSAGE,
                transactionId = response.ID
            };
            ApiResponse<object> apiResponse1 = await _iTSG_Notification.SendSMS(payload);
            return Ok();
        }

        public async Task<List<GrievanceWorkFlowActionResponse>> GetWorkFlow(GrievanceWorkFlowPayload grievanceWorkFlowPayload)
        {

            List<GrievanceWorkFlowActionResponse> obj = new List<GrievanceWorkFlowActionResponse>();
            ApiResponse<object> apiResponse = await _iIssueTracker.GetGrievanceWorkFlowAction(grievanceWorkFlowPayload);
            if (apiResponse != null || apiResponse.Response != null)
            {
                obj = JsonConvert.DeserializeObject<List<GrievanceWorkFlowActionResponse>>(JsonConvert.SerializeObject(apiResponse.Response));

            }
            return obj;

        }
       
        [HttpPost]
        public async Task<ActionResult> RenderActionModal(RenderModel obj)
        {
            var model = new RenderViewModel
            {
                actionId = obj.actionId,
                actionName = obj.actionName,
                destinationStageId = obj.destinationStageId,
                destinationRoleId = obj.destinationRoleId,
                statusId = obj.statusId,
                status = obj.status,
                sourceStageId = obj.sourceStageId,
                grId = obj.grId,
                grievanceId = obj.grievanceId,
                auditId = obj.auditId,
                destinationUserId = obj.destinationUserId,
                moduleId = obj.moduleId,
                subModuleId = obj.subModuleId,
                citizenUserId = obj.citizenUserId,
                ClarificationDetails = string.Empty,
                statusList = new List<StatusList> { new StatusList { statusId = obj.statusId, status = obj.status } }
            };
            var objView = "";
            switch (model.actionName)
            {
                case "REOPEN":
                    objView = "_ReOpenModel";
                    break;                
                default:
                    objView = "";
                    break;
            }
            return PartialView(objView, model);
        }


        [HttpPost]
        public async Task<ActionResult> SubmitStatusUpdate(RenderViewModel obj)
        {
            List<UpdateStatusGrievanceResponse> objresponse = new List<UpdateStatusGrievanceResponse>();
            List<SentSMSResponse> objresponse1 = new List<SentSMSResponse>();
            var grievanceRegistrationPayload = new UpdateStatusGrievancePayload
            {
                ACTION_ID = obj.actionId,
                AUDIT_ID = obj.auditId,
                DESTINATION_ROLE_ID = obj.destinationRoleId,
                DESTINATION_STAGE_ID = obj.destinationStageId,
                DESTINATION_USER_ID = obj.destinationUserId,
                GRIEVANCE_ID = obj.grievanceId,
                GR_ID = obj.grId,
                PROJECT_ID = 1,
                MODIFIED_BY = "SANDEEPKUMAR641989",
                SOURCE_ROLE_ID = 35,
                SOURCE_STAGE_ID = obj.sourceStageId,
                STATUS_ID = obj.statusId,
                USER_COMMENT = obj.ClarificationDetails,
                USER_ID = obj.citizenUserId
            };

            ApiResponse<object> apiResponse = await _iTSG_Notification.updateStatusGrievance(grievanceRegistrationPayload);

            if (apiResponse != null || apiResponse.Response != null)
            {
                objresponse = JsonConvert.DeserializeObject<List<UpdateStatusGrievanceResponse>>(JsonConvert.SerializeObject(apiResponse.Response));
                
            }

            //foreach (var item in objresponse)
            //{
            //    var payload = new SendSMSPayload
            //    {
            //        action_ID = item.ACTION_ID,
            //        mobileNumber = item.MOBILE_NUMBER,
            //        project_ID = item.PROJECT_ID,
            //        templateId = item.SMSTEMPLATE_ID,
            //        templateSMS = item.TEMPLATEMESSAGE,
            //        transactionId = item.ID
            //    };
            //    ApiResponse<object> apiResponse1 = await _iTSG_Notification.SendSMS(payload);

            //    if (apiResponse != null || apiResponse.Response != null)
            //    {
            //        objresponse1 = JsonConvert.DeserializeObject<List<SentSMSResponse>>(JsonConvert.SerializeObject(apiResponse.Response));

            //    }
            //}

            SwalHelper_TSG.SetSwalAlert(TempData, "Welcome", apiResponse.Message, "success");
            return Redirect("Register");
        }
    }
}
