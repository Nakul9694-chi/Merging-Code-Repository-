﻿using DocumentFormat.OpenXml.Drawing.Charts;
using IEMS.FrontEnd.Common.Common;
using IEMS.FrontEnd.Interface.IssueTracker_TSG;
using IEMS.FrontEnd.Models;
using IEMS.FrontEnd.Models.Common_TSG;
using IEMS.FrontEnd.Models.MasterModule;
using IEMS.FrontEnd.Models.Purchase_TSG;
using IEMS.FrontEnd.Models.TSG_Notification.Notification;
using IEMS.FrontEnd.Models.TSG_Notification.Notification.Payload;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.Globalization;
using static IEMS.FrontEnd.Models.TSG_Notification.Notification.IssuesModel;

namespace IEMS.BUGTRACKER.Areas.IssueTracker.Controllers
{
    [Area("IssueTracker")]
    public class TSG_NotificationController : BaseController
    {

        private static List<SelectListItem> Departments = new List<SelectListItem>
        {
            new SelectListItem{ Value = "1", Text = "EXCISE DEPARTMENT" },
            new SelectListItem{ Value = "2", Text = "RAJASTHAN STATE BEVERAGES CORPORATION LTD." },
            new SelectListItem{ Value = "3", Text = "RAJASTHAN STATE GANGANAGAR SUGAR MILS LTD." }
        };

        private static List<SelectListItem> Modules = new List<SelectListItem>
        {
            new SelectListItem{ Value = "64", Text = "EDC" },
            new SelectListItem{ Value = "62", Text = "LICENSE RENEWAL" },
            new SelectListItem{ Value = "1", Text = "ONLINE OFS" }
        };

        private static List<SelectListItem> SubModules = new List<SelectListItem>
        {
            new SelectListItem{ Value = "1", Text = "SubModule X" },
            new SelectListItem{ Value = "2", Text = "SubModule Y" }
        };


        private static List<StatusOption> GrievanceStatus = new List<StatusOption>
        {
            new StatusOption { Id = "1", FullName = "OPEN" },
            new StatusOption { Id = "3", FullName = "In Progress" },
            new StatusOption { Id = "5", FullName = "REOPEN" },
            new StatusOption { Id = "6", FullName = "SOUGHT FOR CLARIFICATION" },
            new StatusOption { Id = "7", FullName = "RESOLVED" },
            new StatusOption { Id = "42", FullName = "CLOSE" }
        };


        private readonly ITSG_Notification _iTSG_Notification;


        public TSG_NotificationController(ITSG_Notification iTSG_Notification)
        {
            _iTSG_Notification = iTSG_Notification;
        }

        [HttpGet]
        public async Task<ActionResult> Issues()
        {
            List<GrievanceRegistrationData> objData = new List<GrievanceRegistrationData>();
            List<GrievanceWorkFlowAction> objWorkFlowAction = new List<GrievanceWorkFlowAction>();
            var formUserMGMasterData = new MasterDropDownInput
            {
                Action = "SEVERITY",
                Id = 0,
                IsActive = 1
            };
            ApiResponse<object> apiResponse1 = await _iTSG_Notification.getUserMGMasterData(formUserMGMasterData);
            var formUserMGMasterData1 = new MasterDropDownInput
            {
                Action = "GRIEVANCE_STATUS",
                Id = 0,
                IsActive = 1
            };
            ApiResponse<object> apiResponse2 = await _iTSG_Notification.getUserMGMasterData(formUserMGMasterData1);

            var grievanceRegistrationPayload = new GrievanceDataPayload
            {
                ACTION = "ALL",
                // SSOID = "SANDEEPKUMAR641989",
                SSOID = "GSAINI90",
                ROLE_ID = 35,
                GR_ID = 0,
                //USER_ID = 207
                USER_ID = 209
            };
            ApiResponse<object> apiResponse3 = await _iTSG_Notification.getGrievanceRegistrationData(grievanceRegistrationPayload);
            if (apiResponse3 != null || apiResponse3.Response != null)
            {
                objData = JsonConvert.DeserializeObject<List<GrievanceRegistrationData>>(JsonConvert.SerializeObject(apiResponse3.Response));
            }

            var grievanceWorkFlowPayload = new GrievanceWorkFlowPayload
            {
                ACTION = "UPDATE",
                PROJECT_ID = 1,
                SOURCE_ROLE_ID = 37,
                SOURCE_STAGE_ID = 4
                //SOURCE_ROLE_ID = 35,
                //SOURCE_STAGE_ID = 3
            };
            ApiResponse<object> apiResponse4 = await _iTSG_Notification.getGrievanceWorkFlowAction(grievanceWorkFlowPayload);
            if (apiResponse4 != null || apiResponse4.Response != null)
            {
                objWorkFlowAction = JsonConvert.DeserializeObject<List<GrievanceWorkFlowAction>>(JsonConvert.SerializeObject(apiResponse4.Response));
            }

            var model = new IssueViewModel
            {
                Filter = new IssueFilter(),
                Issues = objData,
                GrievanceStatus = GrievanceStatus,
                GrievanceWorkflowActions = objWorkFlowAction
            };
            return View(model);
        }

        [HttpPost]
        public async Task<ActionResult> Issues(IssueFilter filter, string searchKey)
        {
            List<GrievanceRegistrationData> obj = new List<GrievanceRegistrationData>();
            List<GrievanceWorkFlowAction> objWorkFlowAction = new List<GrievanceWorkFlowAction>();
            var grievanceRegistrationPayload = new GrievanceRegistrationPayload
            {
                ACTION = "LIST_FILTER",
                SSOID = "SANDEEPKUMAR641989",
                ROLE_ID = 35,
                GR_ID = 0,
                USER_ID = 207,
                STATUS_ID = Convert.ToInt16(filter.Status),
                FROM_DATE = filter.DateFrom?.ToString("dd-MMM-yyyy"),
                TO_DATE = filter.DateTo?.ToString("dd-MMM-yyyy")
            };

            ApiResponse<object> apiResponse3 = await _iTSG_Notification.getGrievanceRegistrationListFilterData(grievanceRegistrationPayload);

            if (apiResponse3 != null || apiResponse3.Response != null)
            {
                obj = JsonConvert.DeserializeObject<List<GrievanceRegistrationData>>(JsonConvert.SerializeObject(apiResponse3.Response));

            }

            var grievanceWorkFlowPayload = new GrievanceWorkFlowPayload
            {
                ACTION = "UPDATE",
                PROJECT_ID = 1,
                SOURCE_ROLE_ID = 35,
                SOURCE_STAGE_ID = 3
            };
            ApiResponse<object> apiResponse4 = await _iTSG_Notification.getGrievanceWorkFlowAction(grievanceWorkFlowPayload);
            if (apiResponse4 != null || apiResponse4.Response != null)
            {
                objWorkFlowAction = JsonConvert.DeserializeObject<List<GrievanceWorkFlowAction>>(JsonConvert.SerializeObject(apiResponse4.Response));
            }
            var filteredIssues = obj.AsEnumerable();

            if (filter != null)
            {
                if (filter.DateFrom.HasValue)
                    filteredIssues = filteredIssues.Where(i => DateTime.Parse(i.CREATED_DATE).Date >= filter.DateFrom.Value.Date);

                if (filter.DateTo.HasValue)
                    filteredIssues = filteredIssues.Where(i => DateTime.Parse(i.CREATED_DATE).Date <= filter.DateTo.Value.Date);

                if (filter.Status != null)
                {
                    filteredIssues = filteredIssues.Where(i => i.STATUS_ID == grievanceRegistrationPayload.STATUS_ID);
                }
            }

            if (!string.IsNullOrWhiteSpace(searchKey))
            {
                var key = searchKey.ToLower();
                filteredIssues = filteredIssues.Where(i =>
                    i.GRIEVANCE_ID.ToLower().Contains(key) ||
                    i.STATUS.ToLower().Contains(key) ||
                    i.SSOID.ToLower().Contains(key));
            }

            var model = new IssueViewModel
            {
                Filter = filter ?? new IssueFilter(),
                SearchKey = searchKey,
                Issues = filteredIssues.ToList(),
                GrievanceStatus = GrievanceStatus,
                GrievanceWorkflowActions = objWorkFlowAction
            };

            return View(model);
        }

        [HttpGet]
        public async Task<ActionResult> GetIssueTrackerHistory(int issueId)
        {
            // TODO: Replace below with real data retrieval based on issueId
            List<GrievanceTrail> trailData = new List<GrievanceTrail>();
            List<GrievanceData> grvData = new List<GrievanceData>();
            var grievanceTrailPayload = new GrievanceRegistrationPayload
            {
                ACTION = "HISTORY",
                SSOID = "SANDEEPKUMAR641989",
                ROLE_ID = 35,
                GR_ID = issueId,
                USER_ID = 0,
                STATUS_ID = 0,
                FROM_DATE = "",
                TO_DATE = ""
            };

            ApiResponse<object> apiResponse = await _iTSG_Notification.getGrievanceRegistrationListFilterData(grievanceTrailPayload);

            if (apiResponse != null || apiResponse.Response != null)
            {
                trailData = JsonConvert.DeserializeObject<List<GrievanceTrail>>(JsonConvert.SerializeObject(apiResponse.Response));

            }

            var grievanceHistoryPayload = new GrievanceRegistrationPayload
            {
                ACTION = "BY_GRIEVANCE_ID",
                SSOID = "SANDEEPKUMAR641989",
                ROLE_ID = 35,
                GR_ID = issueId,
                USER_ID = 0,
                STATUS_ID = 0,
                FROM_DATE = "",
                TO_DATE = ""
            };

            ApiResponse<object> apiResponse1 = await _iTSG_Notification.getGrievanceRegistrationListFilterData(grievanceHistoryPayload);

            if (apiResponse1 != null || apiResponse1.Response != null)
            {
                grvData = JsonConvert.DeserializeObject<List<GrievanceData>>(JsonConvert.SerializeObject(apiResponse1.Response));

            }
            var model = new IssueHistory
            {
                GrievanceGetBasicDataModel = grvData,
                GrievanceTrailModel = trailData
            };

            return PartialView("_IssueTrackerHistory", model);
        }

        [HttpPost]
        public async Task<ActionResult> RenderActionModal(RenderModel obj)
        {
            List<GrievanceUserActionResponse> objresponse = new List<GrievanceUserActionResponse>();
            var model = new RenderViewModel
            {
                actionId = obj.actionId,
                actionName = obj.actionName,
                destinationStageId = obj.destinationStageId,
                destinationRoleId = obj.destinationRoleId,
                statusId = obj.statusId,
                status = obj.status,
                sourceStageId = obj.sourceStageId,
                grId = obj.grId,
                grievanceId = obj.grievanceId,
                auditId = obj.auditId,
                destinationUserId = obj.destinationUserId,
                moduleId = obj.moduleId,
                subModuleId = obj.subModuleId,
                citizenUserId = obj.citizenUserId,
                ClarificationDetails = string.Empty,
                statusList = new List<StatusList> { new StatusList { statusId = obj.statusId, status = obj.status } },
                UserActionList = new List<GrievanceUserActionResponse> { new GrievanceUserActionResponse { } }
            };
            if (obj.actionName.Equals("forward", StringComparison.CurrentCultureIgnoreCase))
            {
                var payload = new GrievanceUserActionPayload
                {
                    ACTION = "GET_USER_BY_MODULE/SUBMODULE",
                    MODULE_ID = 1,
                    ROLE_ID = 37,
                    SSOID = "SANDEEPKUMAR641989",
                    SUBMODULE_ID = 21
                };
                ApiResponse<object> apiResponse = await _iTSG_Notification.getGrievanceUserAction(payload);

                if (apiResponse != null || apiResponse.Response != null)
                {
                    objresponse = JsonConvert.DeserializeObject<List<GrievanceUserActionResponse>>(JsonConvert.SerializeObject(apiResponse.Response));
                }
                if (objresponse.Count > 0)
                {
                    model.UserActionList = objresponse;
                }
            }

            if (obj.actionName.Equals("delegate", StringComparison.CurrentCultureIgnoreCase))
            {
                var payload = new GrievanceUserActionPayload
                {
                    ACTION = "DELEGATE",
                    MODULE_ID = 1,
                    ROLE_ID = 37,
                    SSOID = "GSAINI90",
                    SUBMODULE_ID = 22
                };
                ApiResponse<object> apiResponse = await _iTSG_Notification.getGrievanceUserAction(payload);

                if (apiResponse != null || apiResponse.Response != null)
                {
                    objresponse = JsonConvert.DeserializeObject<List<GrievanceUserActionResponse>>(JsonConvert.SerializeObject(apiResponse.Response));
                }
                if (objresponse.Count > 0)
                {
                    model.UserActionList = objresponse;
                }
            }

            var objView = "";
            switch (model.actionName)
            {
                case "Clarification":
                    objView = "_ShowModal";
                    break;
                case "Delegate":
                    objView = "_DelegateModal";
                    break;
                case "Forward":
                    objView = "_ForwardModal";
                    break;
                default:
                    objView = "_VerifyModal";
                    break;
            }
            return PartialView(objView, model);
        }

        [HttpPost]
        public async Task<ActionResult> SubmitStatusUpdate(RenderViewModel obj)
        {
            List<UpdateStatusGrievanceResponse> objresponse = new List<UpdateStatusGrievanceResponse>();
            List<SentSMSResponse> objresponse1 = new List<SentSMSResponse>();
            var grievanceRegistrationPayload = new UpdateStatusGrievancePayload
            {
                ACTION_ID = obj.actionId,
                AUDIT_ID = obj.auditId,
                DESTINATION_ROLE_ID = obj.destinationRoleId,
                DESTINATION_STAGE_ID = obj.destinationStageId,
                DESTINATION_USER_ID = Convert.ToInt32(obj.ForwardTo) == 0 ? obj.destinationUserId : Convert.ToInt32(obj.ForwardTo),
                GRIEVANCE_ID = obj.grievanceId,
                GR_ID = obj.grId,
                PROJECT_ID = 1,
                MODIFIED_BY = "SANDEEPKUMAR641989",
                SOURCE_ROLE_ID = 35,
                SOURCE_STAGE_ID = obj.sourceStageId,
                STATUS_ID = obj.statusId,
                USER_COMMENT = obj.ClarificationDetails,
                USER_ID = obj.citizenUserId
            };

            ApiResponse<object> apiResponse = await _iTSG_Notification.updateStatusGrievance(grievanceRegistrationPayload);

            if (apiResponse != null || apiResponse.Response != null)
            {
                objresponse = JsonConvert.DeserializeObject<List<UpdateStatusGrievanceResponse>>(JsonConvert.SerializeObject(apiResponse.Response));

            }

            foreach (var item in objresponse)
            {
                var payload = new SendSMSPayload
                {
                    action_ID = item.ACTION_ID,
                    mobileNumber = item.MOBILE_NUMBER,
                    project_ID = item.PROJECT_ID,
                    templateId = item.SMSTEMPLATE_ID,
                    templateSMS = item.TEMPLATEMESSAGE,
                    transactionId = item.ID
                };
                ApiResponse<object> apiResponse1 = await _iTSG_Notification.SendSMS(payload);

                if (apiResponse != null || apiResponse.Response != null)
                {
                    objresponse1 = JsonConvert.DeserializeObject<List<SentSMSResponse>>(JsonConvert.SerializeObject(apiResponse.Response));

                }
            }

            SwalHelper_TSG.SetSwalAlert(TempData, "Welcome", apiResponse.Message, "success");
            return Redirect("Issues");
        }

        [HttpGet]
        public async Task<ActionResult> GrievanceReport()
        {
            var model = new IssueReportViewModel
            {
                Departments = Departments,
                Modules = Modules,
                SubModules = SubModules,
                IssueReports = new List<GrievanceCountResponse>() { new() },
                DrillDownItems = new List<GrievanceCountDetailResponse>() { new() },
                Filter = new IssueReportFilterViewModel(),
            };

            // Set default dates to today and a month ago
            model.Filter.DateFrom = DateTime.Today.AddMonths(-1);
            model.Filter.DateTo = DateTime.Today;
            return View(model);
        }

        [HttpPost]
        public async Task<ActionResult> GrievanceReport(IssueReportFilterViewModel filter)
        {
            List<GrievanceCountResponse> obj = new List<GrievanceCountResponse>();
            var grievanceCountPayload = new GrievanceCountPayload
            {
                DEPT_ID = filter.DepartmentId,
                MODULE_ID = filter.ModuleId,
                SUB_MODULE_ID = filter.SubModuleId,
                FROM_DATE = filter.DateFrom?.ToString("dd-MM-yyyy"),
                TO_DATE = filter.DateTo?.ToString("dd-MM-yyyy")
            };

            ApiResponse<object> apiResponse3 = await _iTSG_Notification.getGrievanceCount(grievanceCountPayload);

            if (apiResponse3 != null || apiResponse3.Response != null)
            {
                obj = JsonConvert.DeserializeObject<List<GrievanceCountResponse>>(JsonConvert.SerializeObject(apiResponse3.Response));

            }

            var filteredIssues = obj.AsEnumerable();

            if (filter != null)
            {
                if (filter.DateFrom.HasValue)
                    filteredIssues = filteredIssues.Where(i => DateTime.Parse(i.FROM_DATE).Date >= filter.DateFrom.Value.Date);

                if (filter.DateTo.HasValue)
                    filteredIssues = filteredIssues.Where(i => DateTime.Parse(i.TO_DATE).Date <= filter.DateTo.Value.Date);

                if (filter.DepartmentId != 0)
                {
                    filteredIssues = filteredIssues.Where(i => i.DEPT_ID == filter.DepartmentId);
                }
            }


            var model = new IssueReportViewModel
            {
                Departments = Departments,
                Modules = Modules,
                SubModules = SubModules,
                IssueReports = filteredIssues.ToList(),
                DrillDownItems = new List<GrievanceCountDetailResponse>() { new() },
                Filter = filter,
            };

            return View(model);
        }

        [HttpPost]
        public async Task<ActionResult> GrievanceDrilldown(string RowJson, string Type, string FilterJson)
        {
            if (string.IsNullOrEmpty(RowJson))
            {
                return BadRequest("No data received.");
            }

            // Deserialize JSON to your model type
            var request = JsonConvert.DeserializeObject<GrievanceCountResponse>(RowJson);
            var filter = JsonConvert.DeserializeObject<IssueReportFilterViewModel>(FilterJson);
            var obj = new List<GrievanceCountDetailResponse> { new() };

            var model = new IssueReportViewModel
            {
                Departments = Departments,
                Modules = Modules,
                SubModules = SubModules,
                IssueReports = new List<GrievanceCountResponse> { new() },
                DrillDownItems = new List<GrievanceCountDetailResponse>() { new() },
                Filter = filter,
            };
                        
            var grievanceCountDetailPayload = new GrievanceCountDetailPayload
            {
                DEPT_ID = request.DEPT_ID,
                MODULE_ID = request.MODULE_ID,
                SUB_MODULE_ID = request.SUB_MODULE_ID,
                FROM_DATE = Convert.ToDateTime(request.FROM_DATE).ToString("dd-MM-yyyy"),
                TO_DATE = Convert.ToDateTime(request.TO_DATE).ToString("dd-MM-yyyy"),
                REPORT_ACTION = Type
            };
            ApiResponse<object> apiResponse3 = await _iTSG_Notification.getGrievanceCountDetail(grievanceCountDetailPayload);

            if (apiResponse3 != null || apiResponse3.Response != null)
            {
                obj = JsonConvert.DeserializeObject<List<GrievanceCountDetailResponse>>(JsonConvert.SerializeObject(apiResponse3.Response));
            }
            model.DrillDownItems = obj;
            return View("GrievanceDrilldown", model);
        }
    }
}
