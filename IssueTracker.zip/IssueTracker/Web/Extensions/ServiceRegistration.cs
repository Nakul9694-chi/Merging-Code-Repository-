using IEMS.FrontEnd.Common;
using IEMS.FrontEnd.Interface;
using IEMS.FrontEnd.Interface.AccessRightsV2;
using IEMS.FrontEnd.Interface.AddBarCounters;
using IEMS.FrontEnd.Interface.AirportShop;
using IEMS.FrontEnd.Interface.Audit_Master;
using IEMS.FrontEnd.Interface.AuditDeposit;
using IEMS.FrontEnd.Interface.AuditEntry;
using IEMS.FrontEnd.Interface.BakayaDeposit;
using IEMS.FrontEnd.Interface.BakayaEntry;
using IEMS.FrontEnd.Interface.Bank_Integration;
using IEMS.FrontEnd.Interface.Bhang;
using IEMS.FrontEnd.Interface.BhangGroupMaster;
using IEMS.FrontEnd.Interface.BhangPermit;
using IEMS.FrontEnd.Interface.BrandApprovalReport;
using IEMS.FrontEnd.Interface.BrandOwnerShip;
using IEMS.FrontEnd.Interface.CaneProduction;
using IEMS.FrontEnd.Interface.CommonExtension;
using IEMS.FrontEnd.Interface.Complaints;
using IEMS.FrontEnd.Interface.CompositeProfile;
using IEMS.FrontEnd.Interface.CountryLiquorClosing;
using IEMS.FrontEnd.Interface.CountryLiquorRmlRate;
using IEMS.FrontEnd.Interface.CRM;
using IEMS.FrontEnd.Interface.DepartmentServ;
using IEMS.FrontEnd.Interface.DepotDamage;
using IEMS.FrontEnd.Interface.DepotDrainOut;
using IEMS.FrontEnd.Interface.DepoTransfers;
using IEMS.FrontEnd.Interface.DepotSale;
using IEMS.FrontEnd.Interface.Dispatchnotecreation;
using IEMS.FrontEnd.Interface.Egras;
using IEMS.FrontEnd.Interface.EGrassChallan;
using IEMS.FrontEnd.Interface.ErrorLog;
using IEMS.FrontEnd.Interface.Esign;
using IEMS.FrontEnd.Interface.EVCEntry;
using IEMS.FrontEnd.Interface.ExciseShopMaster_Request;
using IEMS.FrontEnd.Interface.FeeStructure;
using IEMS.FrontEnd.Interface.FileUpload;
using IEMS.FrontEnd.Interface.FIR;
using IEMS.FrontEnd.Interface.FIRModule;
using IEMS.FrontEnd.Interface.FL4Request;
using IEMS.FrontEnd.Interface.General;
using IEMS.FrontEnd.Interface.GoodsRejection;
using IEMS.FrontEnd.Interface.GrnAllDetailss;
using IEMS.FrontEnd.Interface.GstMaster;
using IEMS.FrontEnd.Interface.Gurantee;
using IEMS.FrontEnd.Interface.Help;
using IEMS.FrontEnd.Interface.Hologram;
using IEMS.FrontEnd.Interface.IssueTracker_TSG;
using IEMS.FrontEnd.Interface.ITPVoucher;
using IEMS.FrontEnd.Interface.LicenseShopAndNokarnama;
using IEMS.FrontEnd.Interface.LiquorRatePacking;
using IEMS.FrontEnd.Interface.LSM;
using IEMS.FrontEnd.Interface.Manufacturer;
using IEMS.FrontEnd.Interface.MasterModule;
using IEMS.FrontEnd.Interface.MFG_Unit_Renewal_Request;
using IEMS.FrontEnd.Interface.MstRetailOnRenewalFeeType;
using IEMS.FrontEnd.Interface.OccasionalReport;
using IEMS.FrontEnd.Interface.OFSReport;
using IEMS.FrontEnd.Interface.OnlinePermitGenerate;
using IEMS.FrontEnd.Interface.OrderForSupply;
using IEMS.FrontEnd.Interface.OtherLicensee;
using IEMS.FrontEnd.Interface.Production;
using IEMS.FrontEnd.Interface.Purchase;
using IEMS.FrontEnd.Interface.Purchase_TSG;
using IEMS.FrontEnd.Interface.PurchaseReportInterface;
using IEMS.FrontEnd.Interface.QueryWizard;
using IEMS.FrontEnd.Interface.RateApproval;
using IEMS.FrontEnd.Interface.RateApproval.Requests;
using IEMS.FrontEnd.Interface.RCVarification;
using IEMS.FrontEnd.Interface.ReportBankChallanRegisters;
using IEMS.FrontEnd.Interface.Reports;
using IEMS.FrontEnd.Interface.RetailOff;
using IEMS.FrontEnd.Interface.RetailOffLicenseeFee;
using IEMS.FrontEnd.Interface.RetailOn;
using IEMS.FrontEnd.Interface.RSBCLIndent;
using IEMS.FrontEnd.Interface.RSGSMIndent.Interface;
using IEMS.FrontEnd.Interface.RSGSMIndentRML.Interface;
using IEMS.FrontEnd.Interface.SaleAndExciseDutySummaryReport;
using IEMS.FrontEnd.Interface.SaleSummary;
using IEMS.FrontEnd.Interface.Sampling;
using IEMS.FrontEnd.Interface.SaveIp;
using IEMS.FrontEnd.Interface.SpiritExportNOC;
using IEMS.FrontEnd.Interface.SpiritImport;
using IEMS.FrontEnd.Interface.SpiritReceive;
using IEMS.FrontEnd.Interface.SSO;
using IEMS.FrontEnd.Interface.StockManagement;
using IEMS.FrontEnd.Interface.StockTransaction;
using IEMS.FrontEnd.Interface.SugarSale;
using IEMS.FrontEnd.Interface.SupplierDepotWiseSale;
using IEMS.FrontEnd.Interface.TcsEntry;
using IEMS.FrontEnd.Interface.TicketSystem;
using IEMS.FrontEnd.Interface.TNT;
using IEMS.FrontEnd.Interface.TransferInOut;
using IEMS.FrontEnd.Interface.TSG_Production.TSG_GrainMaster;
using IEMS.FrontEnd.Interface.VanDetails;
using IEMS.FrontEnd.Interface.Vat;
using IEMS.FrontEnd.Interface.Wallet;
using IEMS.FrontEnd.Interface.WorkFlowMaster;
using IEMS.FrontEnd.Services;
using IEMS.FrontEnd.Services.AccessRightsV2;
using IEMS.FrontEnd.Services.Audit_Master;
using IEMS.FrontEnd.Services.AuditDeposit;
using IEMS.FrontEnd.Services.AuditEntry;
using IEMS.FrontEnd.Services.BakayaEntry;
using IEMS.FrontEnd.Services.Bank_Integration;
using IEMS.FrontEnd.Services.Bhang;
using IEMS.FrontEnd.Services.BhangGroupMaster;
using IEMS.FrontEnd.Services.BhangPermitServices;
using IEMS.FrontEnd.Services.BrandApprovalReport;
using IEMS.FrontEnd.Services.BrandOwnerShip;
using IEMS.FrontEnd.Services.CaneProduction;
using IEMS.FrontEnd.Services.CommonExtension;
using IEMS.FrontEnd.Services.Complaints;
using IEMS.FrontEnd.Services.CompositeProfile;
using IEMS.FrontEnd.Services.CountryLiquorClosing;
using IEMS.FrontEnd.Services.CountryLiquorRmlRate;
using IEMS.FrontEnd.Services.CRM;
using IEMS.FrontEnd.Services.DepartmentServ;
using IEMS.FrontEnd.Services.DepotDamage;
using IEMS.FrontEnd.Services.DepotDrainOut;
using IEMS.FrontEnd.Services.DepoTransfers;
using IEMS.FrontEnd.Services.DepotSale;
using IEMS.FrontEnd.Services.Dispatchnotecreation;
using IEMS.FrontEnd.Services.Egras;
using IEMS.FrontEnd.Services.EGrassChallan;
using IEMS.FrontEnd.Services.Esign;
using IEMS.FrontEnd.Services.EVCEntry;
using IEMS.FrontEnd.Services.ExciseShopMaster_Request;
using IEMS.FrontEnd.Services.FeeStructure;
using IEMS.FrontEnd.Services.FileUpload_Services;
using IEMS.FrontEnd.Services.FIR;
using IEMS.FrontEnd.Services.FIRModule;
using IEMS.FrontEnd.Services.FL4Request;
using IEMS.FrontEnd.Services.General;
using IEMS.FrontEnd.Services.GoodsRejection;
using IEMS.FrontEnd.Services.GrnAllDetails;
using IEMS.FrontEnd.Services.GstMaster;
using IEMS.FrontEnd.Services.Gurantee;
using IEMS.FrontEnd.Services.Help;
using IEMS.FrontEnd.Services.Hologram;
using IEMS.FrontEnd.Services.IssueTracker_TSG;
using IEMS.FrontEnd.Services.ITPVoucher;
using IEMS.FrontEnd.Services.LicenseShopAndNokarnama;
using IEMS.FrontEnd.Services.LiquorRatePacking;
using IEMS.FrontEnd.Services.LSM;
using IEMS.FrontEnd.Services.Manufacturer;
using IEMS.FrontEnd.Services.MasterModule;
using IEMS.FrontEnd.Services.MFG_Unit_Renewal_Request;
using IEMS.FrontEnd.Services.MstRetailOnRenewalFeeType;
using IEMS.FrontEnd.Services.OccasionalReport;
using IEMS.FrontEnd.Services.OFSReport;
using IEMS.FrontEnd.Services.OnlinePermitGenerate;
using IEMS.FrontEnd.Services.OrderForSupply;
using IEMS.FrontEnd.Services.OrderForSupplys;
using IEMS.FrontEnd.Services.OtherLicensee;
using IEMS.FrontEnd.Services.Production;
using IEMS.FrontEnd.Services.Purchase;
using IEMS.FrontEnd.Services.Purchase_TSG;
using IEMS.FrontEnd.Services.PurchaseReportServices;
using IEMS.FrontEnd.Services.QueryWizard;
using IEMS.FrontEnd.Services.RateApproval;
using IEMS.FrontEnd.Services.RCVarification;
using IEMS.FrontEnd.Services.ReportBankChallanRegisters;
using IEMS.FrontEnd.Services.Reports;
using IEMS.FrontEnd.Services.RetailOff;
using IEMS.FrontEnd.Services.RetailOffLicenseeFee;
using IEMS.FrontEnd.Services.RetailOn;
using IEMS.FrontEnd.Services.RetailOns;
using IEMS.FrontEnd.Services.RSBCLIndent;
using IEMS.FrontEnd.Services.RSGSMIndent;
using IEMS.FrontEnd.Services.RSGSMIndentRML;
using IEMS.FrontEnd.Services.SaleAndExciseDutySummaryReport;
using IEMS.FrontEnd.Services.Sampling;
using IEMS.FrontEnd.Services.SaveIp;
using IEMS.FrontEnd.Services.SpiritExportNOC;
using IEMS.FrontEnd.Services.SpiritImport;
using IEMS.FrontEnd.Services.SpiritReceive;
using IEMS.FrontEnd.Services.SSO;
using IEMS.FrontEnd.Services.StockManagement;
using IEMS.FrontEnd.Services.StockTransaction;
using IEMS.FrontEnd.Services.SugarSale;
using IEMS.FrontEnd.Services.SupplierDepotWiseSale;
using IEMS.FrontEnd.Services.TcsRateEntry;
using IEMS.FrontEnd.Services.TicketSystem;
using IEMS.FrontEnd.Services.TNT;
using IEMS.FrontEnd.Services.TransferInOut;
using IEMS.FrontEnd.Services.TSG_Production.TSG_GrainMaster;
using IEMS.FrontEnd.Services.TSG_IssueTracker;
using IEMS.FrontEnd.Services.VanDetails;
using IEMS.FrontEnd.Services.Vat;
using IEMS.FrontEnd.Services.Wallet;
using IEMS.FrontEnd.Services.WorkFlowMaster;
using IEMS_WEB.Areas.OnlinePermitGenerate.Services;
using IEMS_WEB.Areas.Purchase.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.Extensions.DependencyInjection.Extensions;
using static IEMS.FrontEnd.Services.MasterModule.StateServices;
using static IEMS.FrontEnd.Services.MenuSerivces;
using IEMS.FrontEnd.Interface.TSG_Production.TSG_PlantManagement;
using IEMS.FrontEnd.Services.TSG_Production.TSG_PlantManagement;
using IEMS.FrontEnd.Services.TSG_Production;
using IEMS.FrontEnd.Interface.TSG_Production;


namespace IEMS.Web.Extensions
{

    public static class ServiceRegistration
    {

        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            services.AddControllersWithViews();
            services.AddHttpClient();


            services.TryAddTransient<IPackage, PackageServices>();

            //services.TryAddTransient<IMaster, MasterService>();
            //services.TryAddTransient<IState, StateServices>();

            ///!!!!!!!!!!!Area Name Must Be in the Region!!!!!!!!!!!!////////////////////
            ///
            #region TSG Production

            services.AddScoped<ITSG_GrainMasterList, GrainMasterService>();
            services.AddScoped<IPlantManagement, PlantManagementService>();
            services.AddScoped<ITemplateManagement, TemplateManagementService>();
            services.AddScoped<IThresholdsDetails, ThresholdsService>();
            services.AddScoped<IProductionOperator, ProductionOperatorService>();
            services.AddScoped<ILabTestRules, LabTestRulesService>();
            #endregion


            #region TSG Purchase
            services.AddScoped<ILOATSG, LOATSGService>();
            services.AddScoped<IPOTSG, POTSGService>();
            services.AddScoped<IAPOTSG, APOTSGService>();
            services.AddScoped<ITenderProcess, TSG_RSGSM_TenderProcess>();
            services.AddScoped<IReportTSG, ReportTSGService>();
            services.AddScoped<IWPSTSG, WPSTSGService>();
            #endregion

            #region TSG IssueTracker
            services.AddScoped<ITSG_Notification, TSG_Notification>();
            #endregion
            #region TSG Issue Tracker
            services.AddScoped<IIssueTracker, IssueTrackerService>();
            #endregion
            #region Master
            services.TryAddTransient<IAuditDeposit, AuditDepositServices>();
            services.TryAddTransient<IAuditMaster, AuditMasterServices>();
            services.TryAddTransient<IAuditEntry, AuditEntryServices>();

            services.TryAddTransient<IEVCEntry, EVCEntryService>();
            services.TryAddTransient<IPackage, PackageServices>();
            services.TryAddTransient<IMenu, MenuService>();

            services.TryAddTransient<IBank, BankServices>();
            services.TryAddTransient<IProductGroup, ProductServices>();
            services.TryAddTransient<IBrandFlavour, BrandFlavourMasterService>();
            services.TryAddTransient<IExciseFee, ExciseFeeService>();
            services.TryAddTransient<IBudgetHead, BudgetHeadService>();
            services.TryAddTransient<ICircleOffice, CircleOfficeService>();
            services.TryAddTransient<IDistrict, DistrictMaster>();
            services.TryAddTransient<ILicenseCategory, IEMS.FrontEnd.Models.MasterModule.LicenseCategoryService>();
            services.TryAddTransient<IZoneMaster, ZoneMasterService>();
            services.TryAddTransient<IBrand, BrandRepo>();
            services.TryAddTransient<IOfficeMaster, OfficeMaster>();
            services.TryAddTransient<ITreasury, TreasuryMasterService>();
            services.TryAddTransient<ILicenseeType, LicenseeTypeService>();
            services.TryAddTransient<IAreaTypeCategory, AreaCatregoryServices>();
            services.TryAddTransient<IEMS.FrontEnd.Interface.MasterModule.IRole, RoleServices>();


            services.TryAddTransient<IState, StateServices>();
            services.TryAddTransient<IUnitMaster, UnitCatregoryServices>();
            services.TryAddTransient<Iward, WardService>();
            services.TryAddTransient<IShopCreation, ShopCreationServices>();

            services.TryAddTransient<ICity, CityMasterService>();
            services.TryAddTransient<IBudget, BudgetService>();


            services.TryAddTransient<ILicenseMaster, LicenseMasterServices>();
            services.TryAddTransient<ICountry, CountryServices>();
            services.TryAddTransient<IRouteMaster, RouteMasterServices>();
            services.TryAddTransient<ICommercialPlaceRegistration, CommercialPlaceRegistrationServices>();
            services.TryAddTransient<IDeoMaster, DeoMaster>();
            services.TryAddTransient<IPanchayat, PanchayatDetails>();

            services.TryAddTransient<IProductionGateEntry, ProductionGateEntryService>();
            services.TryAddTransient<ISpiriteIssue, SpiriteIssueService>();
            services.TryAddTransient<ISpiritIssueBlending, SpiritIssueBlendingServicecs>();
            services.TryAddTransient<ISpiritReceive, SpiritReceiveService>();
            services.TryAddTransient<ISpiritIssueForOtherPurpose, SpiritIssueForOtherPurposeServices>();
            services.TryAddTransient<ISpiritIssues, SpritIssuesService>();
            services.TryAddTransient<ILoadingUnloading, LoadingUnloadingService>();
            services.TryAddTransient<IGstMaster, GstMasterService>();
            services.TryAddTransient<IProductMapping, ProductMappingServices>();
            services.TryAddTransient<IOFSLimit, OFSLimitServices>();
            services.TryAddTransient<IProductCategory, ProductCategoryServices>();
            services.TryAddTransient<IMasterUnit, UnitMasterService>();
            services.TryAddTransient<IFileUploadMasterAndDetails, FileUploadMasterAndDetailsService>();
            services.TryAddTransient<IManufactureLicense, ManufactureLicenseService>();
            services.TryAddTransient<ILsmPermitDetails, LsmPermitDetailsService>();
            services.TryAddTransient<ILicenseeStockAndSale, LicenseeStockAndSaleServices>();
            services.TryAddTransient<IOfsReports, OfsReportsServices>();



            #endregion

            #region RC Varification
            services.TryAddTransient<IRCVarification, RCVarificationServices>();
            #endregion

            #region Product Group Item Description
            services.TryAddTransient<IItemDescription, GroupMasterItemDescriptonServices>();
            #endregion
            #region Common
            services.AddScoped<ILogin, LoginServices>();
            services.TryAddTransient<IFileUpload, FileUploadService>();
            services.TryAddTransient<IFileUploadDownload, FileUploadDownloadService>();
            services.TryAddTransient<IDropDownList, IEMS.FrontEnd.Services.DropDownServices>();
            services.TryAddTransient<IEgras, EgrasRepo>();
            services.TryAddTransient<ICreateUser, CreateUserservicecs>();
            services.TryAddTransient<ISSOMapping, MapSSOService>();


            //WorkFlow
            services.TryAddTransient<IAccessRights, AccessRightServices>();
            services.TryAddTransient<IWFInbox, WFInboxService>();
            services.TryAddTransient<IWorkFlow, WorkFlowService>();
            services.TryAddTransient<IMASLocationMaster, MASLocationMasterServices>();
            services.TryAddTransient<IViewLocationDetails, ViewLocationDetailsServices>();
            services.TryAddTransient<IWorkflowObjects, WorkflowObjectsServices>();
            //ADD BY VIKASH KUMAR
            services.TryAddTransient<IAccessRightsV2, AccessRightV2Services>();

            //WorkFlow
            //SSO
            services.TryAddScoped<ISSO, SSOServices>();
            //SSO
            //OTP
            services.TryAddTransient<IOTP, OTPService>();
            //OTP
            services.TryAddTransient<IHelp, HelpService>();

            #endregion

            #region Depot Entry
            services.TryAddTransient<IGateEntry, GateEntryServices>();
            services.TryAddTransient<IDraftMIS, DraftMISServices>();
            services.TryAddTransient<IMenu, MenuService>();
            services.TryAddTransient<IFL_Five, FL_FiveServices>();
            services.TryAddTransient<IFL_Six, FL_SixServices>();
            #endregion

            #region OFS
            services.TryAddTransient<IApplyOFS, ApplyOFSService>();
            services.TryAddTransient<IOFSAcceptance, OFSAcceptanceService>();
            services.TryAddTransient<IPayDutyFee, PayDutyFeeService>();
            services.TryAddTransient<ISupplierInvoice, SupplierInvoiceService>();
            services.TryAddTransient<IGenerateTP, GenerateTPService>();
            services.TryAddTransient<IProductGroupOrgMapping, ProductGroupOrgMapping>();
            services.TryAddTransient<IValidityExtensionOfOFS, ValidityExtensionOfOFSService>();
            services.TryAddTransient<IOFSExtension, OFSExtension>();
            services.TryAddTransient<IValidityExtensionByRSBCL, ValidityExtensionByRSBCLService>();
            services.TryAddTransient<IAllowTNT, AllowTNTService>();
            services.TryAddTransient<ISaveIp, SaveIpServices>();
            services.TryAddTransient<IOfsDetails, OfsDetailsServices>();
            services.TryAddTransient<FetchIp>();
            #endregion

            // OFS CANCELLATION
            #region OFS CANCELLATION
            services.TryAddTransient<IOFSCancellation, OFSCancellationServices>();
            services.TryAddTransient<IOFSCancellationMaster, OFSCancellationMasterServices>();
            services.TryAddTransient<IOFSCancellationDA, OFSCancellationDAServices>();
            services.TryAddTransient<IOFSCancellationMO, OFSCancellationMOServices>();
            services.TryAddTransient<IOFSCancellationGMO, OFSCancellationGMOServices>();
            services.TryAddTransient<IOFSCancellationFetchedSupplier, OFSCancellationSupplierServices>();
            services.TryAddTransient<IOFSCancellationReceivedRSBCL, OFSCancellationReceivedRSBCLServices>();
            services.TryAddTransient<IOFSCancellationIssuanceOrder, OFSCancellationIssuanceOrderServices>();
            services.TryAddTransient<IOFSCancellationCharges, OFSCancellationChargesServices>();
            services.TryAddTransient<IOFSCancellationDocument, OFSCancellationDocumentServices>();
            services.TryAddTransient<IOFSCancellationWorkflow, OFSCancellationWorkflowServices>();
            #endregion

            #region Sprit
            //SPRIT
            services.TryAddTransient<ISpiritImport, SpiritImportService>();
            #endregion

            #region Retail OFF
            services.TryAddTransient<IImportBidders, ImportBiddersService>();
            services.TryAddTransient<IBidderStatus, BidderStausService>();
            services.TryAddTransient<IChallanDetails, ChallanDetailsService>();
            services.TryAddTransient<ILicensePayFee, LicensePayFeeService>();
            services.TryAddTransient<INokarnama, NokarnamaService>();
            services.TryAddTransient<IShopAllocation, ShopAllocationService>();
            services.TryAddTransient<IViewLicenseStatus, ViewLicenseStatusService>();
            services.TryAddTransient<IGodownRequest, GodownRequestSevices>();
            services.TryAddTransient<ILicenseeProfile, LicenseeProfileRepo>();
            services.TryAddTransient<IRetailReport, RetailReportService>();
            #endregion

            #region WorkFlow
            services.TryAddTransient<IWorkFlow, WorkFlowService>();
            #endregion

            #region Retail On
            services.TryAddTransient<ILicenseGeneration, LicenseGenerationService>();
            services.TryAddTransient<IAdditionalBarCounter, AdditionalBarCounterServices>();
            services.TryAddTransient<IBioWholeSaleBond, BioWholeSaleBondService>();
            services.TryAddTransient<IMicroBreweryLicenseRequest, MicroBreweryLicenseRequestService>();

            #endregion

            #region Retail Manufacturer
            services.TryAddTransient<IManufacturerLicenseRegistration, ManufacturerLicRegService>();
            services.TryAddTransient<IManufacturingRenewal, ManufacturingRenewalServices>();
            services.TryAddTransient<IUnitRegistration, UnitRegistrationRepo>();
            services.TryAddTransient<IAlterationMaster, AlterationServices>();
            services.TryAddTransient<IExtraShiftApproval, ExtraShiftApprovalServices>();
            services.TryAddTransient<IAirportShop, AirportShopService>();
            services.TryAddTransient<IBondedWarehouse, BondedWarehouseServices>();
            services.TryAddTransient<ISupplierUnitMaster, SupplierUnitMasterServices>();
            #endregion

            #region Fee Structure
            services.TryAddTransient<ILevyBOMapping, LevyBOMappingService>();
            services.TryAddTransient<ILevyRateMap, LevyMappingService>();
            services.TryAddTransient<ILevyRate, LevyRateCategoryServices>();
            services.TryAddTransient<ILevyRelationMaster, LevyRelationMasterServices>();
            services.TryAddTransient<ILevyTypes, LevyTypesService>();
            services.TryAddTransient<ITransactionType, TransactionTypeService>();

            services.TryAddTransient<IFeeDetails, FeeDetailsServices>();
            services.TryAddTransient<IFeeLicensee, FeeLicenseeServices>();
            services.TryAddTransient<IFeeLicenseeRenewal, FeeLicenseeRenewalServices>();
            services.TryAddTransient<IChallanMaster, MstChallanServices>();
            services.TryAddTransient<IPaymentByDD, PaymentByDDServices>();
            services.TryAddTransient<IBankChallan, BankIntegrationServices>();  // added  by ayush 

            #endregion

            #region Other Licensee
            services.TryAddTransient<IOccasionalLicensee, OccasionalLicenseService>();
            services.TryAddTransient<IOtherLicensee, OtherLicenseService>();
            services.TryAddTransient<IBhangLicenseeRegistration, BhangLicenseeRegistrationService>();
            services.TryAddTransient<IHOReqForBhangLicensee, HOReqForBhangLicenseeService>();
            #endregion

            #region Bhang
            services.TryAddTransient<IBhangGodownRequest, BhangGodownRequestService>();
            services.TryAddTransient<IBhangLicenseGenerate, BhangLicenseGenerateServices>();
            services.TryAddTransient<IBhangNokarnamaRepo, BhangNokarnamaServices>();
            services.TryAddTransient<IBhangShopAllocation, BhangShopAllocationService>();
            #endregion
            services.TryAddTransient<IBhangGroup, BhangGropService>();
            services.TryAddTransient<IGrnAllDetailss, GrnAllService>();
            services.TryAddTransient<IVanNumberDetail, VanDetailService>();
            #region DepotDrainRequest
            services.TryAddTransient<IDepotDrainOut, DepotDrainOutService>();

            #endregion

            #region Sampling
            services.TryAddTransient<ISampling, SamplingService>();
            #endregion

            #region Depot Sale
            services.TryAddTransient<IIndent, IndentService>();
            services.TryAddTransient<IITPIssuance, ITPIssuanceServices>();
            #endregion

            #region Depot Damage
            services.TryAddTransient<IDepotDamage, DepotDamageService>();
            #endregion

            #region OnlineFeeDeposit
            services.TryAddTransient<IChallanSummary, ChallanSummaryService>();
            services.TryAddTransient<ITransSummary, TransSummaryServices>();
            #endregion

            #region Wallet
            services.TryAddTransient<IChallan, ChallanService>();
            services.TryAddTransient<IWalletTransSummaryReport, WalletTransSummaryReportService>();

            #endregion

            #region Sprit Export
            services.TryAddTransient<ISpiritExportApplication, SpiritExportApplicationServices>();
            services.TryAddTransient<ISpiritexport, SpirirtExportService>();
            #endregion

            #region Brand Approval
            services.TryAddTransient<IBrandApproval, BrandApprovalService>();
            services.TryAddTransient<IExciseMaster, ExciseMaster>();
            services.TryAddTransient<IBrandAndLabel, BrandAndLabelService>();
            #endregion

            #region Transfer TOO,TOS,TIS,Too Extension
            services.TryAddTransient<ITransferOut, TransferOutServices>();
            services.TryAddTransient<ITOOExtension, TOOExtensionService>();
            services.TryAddTransient<IMISReport, MISReportService>();


            #endregion

            #region StockInventory

            services.TryAddTransient<IStockTransction, StockTransactionServices>();
            services.TryAddTransient<IMisStockSummary, MisStockSummaryServices>();

            services.TryAddTransient<IBalanceTransaction, BalanceTransactionServices>();
            services.TryAddTransient<IStockManagement, StockManagementServices>();
            #endregion
            #region Cane Production Masters
            services.TryAddTransient<IChakMaster, ChakMasterServices>();
            services.TryAddTransient<ICaneProductionSugarRate, CaneProductionSugarRateServices>();
            services.TryAddTransient<ICaneProductionHsnCode, CaneProductionHsnCodeServices>();
            services.TryAddTransient<ICaneProductionVillage, CaneProductionVillageServices>();
            services.TryAddTransient<ICaneProductionSugarVariety, CaneProductionSugarVarityServices>();
            services.TryAddTransient<ICaneProductionRateConfiguration, CaneProductionRateConfigurationServices>();
            #endregion
            #region Rate Approval
            services.TryAddTransient<ISaleRateEntryByExcise, SaleRateEntryByEciseServices>();
            services.TryAddTransient<IRatePurchaseEntrySection, RatePurchaseEntrySectionServices>();
            services.TryAddTransient<IPriceList, PriceListServices>();
            services.TryAddTransient<ILiquorPurchaseOrderEntry, LiquorPurchaseOrderEntryServices>();
            services.TryAddTransient<IDetailsOfOrganization, DetailsOfOrganizationServices>();
            services.TryAddTransient<IDetailsOfExecutiveAuthorizeToDealWithRSBCL, DetailsOfExecutiveAuthorizeToDealWithRSBCLServices>();
            services.TryAddTransient<IDetailsOfOfficeBearersOfSupplier, DetailsOfOfficeBearersOfSupplierServices>();
            services.TryAddTransient<IExciseDeclarationForSupplier, ExciseDeclarationForSupplierServices>();
            services.TryAddTransient<IOtherStateSale, OtherStateSaleServices>();
            services.TryAddTransient<IOtherCountrySale, OtherCountrySaleServices>();
            #endregion
            #region  Token Creation
            services.TryAddTransient<IToken, TokenService>();
            #endregion
            #region  Final Survey
            services.TryAddTransient<ISurvey, SurveyService>();

            #endregion

            #region  Sugarcane Seniority
            services.TryAddTransient<ISugarcaneSeniority, SugarcaneSeniorityService>();

            #endregion

            #region  Demand Slip
            services.TryAddTransient<IGenerateDemandSlip, GenerateDemandSlipService>();

            #endregion
            #region Sugar Sale
            services.TryAddTransient<IOrderForDelivery, OrderForDeliveryService>();
            #endregion
            #region Department Services and public Services
            services.TryAddTransient<IPublicServices, PublicServicesRepo>();
            services.TryAddTransient<IDepartment, DepartmentService>();
            services.TryAddTransient<IEsignMastercs, EsignServicescs>();
            services.TryAddTransient<IGetEsignConfigration, EsignConfigServices>();
            services.AddSingleton<UniqueCode>();
            services.AddSingleton<CustomIDataProtection>();
            #endregion

            #region ESgin Masters
            services.TryAddTransient<IGetEsignConfigration, EsignConfigServices>();
            #endregion


            #region RateApproval
            //services.TryAddTransient<IRAP_CATEGORY, RateApprovalServices>();
            services.TryAddTransient<IChecklistFiles, ChecklistFilesServices>();
            services.TryAddTransient<IRateApproval, RateApprovalRepo>();
            services.TryAddTransient<ISaleRateEntryByExcise, SaleRateEntryByEciseServices>();
            services.TryAddTransient<IRatePurchaseEntrySection, RatePurchaseEntrySectionServices>();
            services.TryAddTransient<IPriceList, PriceListServices>();
            services.TryAddTransient<ILiquorPurchaseOrderEntry, LiquorPurchaseOrderEntryServices>();
            services.TryAddTransient<IDetailsOfOrganization, DetailsOfOrganizationServices>();
            services.TryAddTransient<IDetailsOfExecutiveAuthorizeToDealWithRSBCL, DetailsOfExecutiveAuthorizeToDealWithRSBCLServices>();
            services.TryAddTransient<IDetailsOfOfficeBearersOfSupplier, DetailsOfOfficeBearersOfSupplierServices>();
            services.TryAddTransient<IExciseDeclarationForSupplier, ExciseDeclarationForSupplierServices>();
            services.TryAddTransient<IOtherStateSale, OtherStateSaleServices>();
            services.TryAddTransient<IOtherCountrySale, OtherCountrySaleServices>();
            services.TryAddTransient<IMinimumEdpEbpOutsideRajasthan, MinimumEdpEbpOutsideRajasthanServices>();
            services.TryAddTransient<IProductionSheet, ProductionCostSheetServices>();
            services.TryAddTransient<IProductionSubCategory, ProductionSubCategoryService>();
            services.TryAddTransient<IProductionCategory, ProductionCategorySerive>();
            services.TryAddTransient<IDetailsOfEdpMrpAdjoiningState, DetailsOfEdpMrpAdjoiningStateServices>();
            services.TryAddTransient<IApprovedBrandDetails, ApprovedBrandDetailsServices>();
            services.TryAddTransient<IDocumentRenewalonMRP, DocumentRenewalonMRPService>();

            #endregion

            #region ITPVoucher
            services.TryAddTransient<IItpVoucher, ItpVoucherService>();
            #endregion
            #region Hologram
            services.TryAddTransient<IIndentRequests, IndentRequestsService>();
            services.TryAddTransient<IBrandCorrection, BrandCorrectionService>();
            services.TryAddTransient<IPrintingRequest, PrintingRequestService>();
            services.TryAddTransient<IProductionDispatch, ProductionDispatchService>();
            services.TryAddTransient<IPurchaseHologramDispatch, PurchaseHologramDispatchService>();
            services.TryAddTransient<IPurchaseOrder, PurchaseOrderService>();
            services.TryAddTransient<IReceivedIndex, ReceivedIndexService>();
            services.TryAddTransient<IReceiveHologramDispatch, ReceiveHologramDispatchService>();
            services.TryAddTransient<ISpoolBoxLabelPrint, SpoolBoxLabelPrintService>();
            services.TryAddTransient<ISpoolBoxMapping, SpoolBoxMappingService>();
            services.TryAddTransient<IIssueSeries, IssueSeriesService>();
            services.TryAddTransient<IIssueDetails, IssueLabelService>();
            services.TryAddTransient<IHologramManagement, HologramManagementService>();
            services.TryAddTransient<IWastageApproval, WastageApprovalService>();
            services.TryAddTransient<IHologramStatus, HologramStatusService>();
            services.TryAddTransient<IBatchSummary, BatchSummaryService>();

            services.TryAddTransient<IHologramProductionPaymentReport, HologramProductionPaymentReportService>();
            #endregion

            #region FeeMasterDetail
            services.TryAddTransient<IFeeMasterDetail, FeeMasterDetailServices>();
            services.TryAddTransient<IDryDay, DryDayService>();
            #endregion

            #region FeeMfgBrand
            services.TryAddTransient<IFeeMfgBrand, FeeMfgBrandServices>();

            #endregion

            #region Pharmacy
            services.TryAddTransient<IPharmacyLicenseRenewal, PharmacyLicenseRenewalServices>();
            services.TryAddTransient<IPharmacyLicRegistration, PharmacyLicRegistraionService>();
            #endregion
            #region manufacturing Renewal
            services.TryAddTransient<IManufacturUnitRenewal, ManufactureService>();
            #endregion
            #region Brand Ownership / Country Liquor
            services.TryAddTransient<IBrandOwnership, BrandOwnerShipServices>();
            services.TryAddTransient<ICountryLiquorRmlRate, CountryLiquoRmlRaterServices>();
            services.TryAddTransient<ILiquorRatePacking, LauorRatePackingServices>();
            services.TryAddTransient<IDIPOpenningEntry, DIPOpenningEntryServices>();
            #endregion

            #region ProductionModule
            services.TryAddTransient<IDIPOpenningEntry, DIPOpenningEntryServices>();
            services.TryAddTransient<IReasonForAbnormalWastage, ReasonForAbnormalWastageServices>();
            services.TryAddTransient<IAbnormalWastage, AbnormalWastageServices>();
            services.TryAddTransient<IBlendingVerification, BlendingVerificationServices>();
            services.TryAddTransient<IBlendingPlusMInus, BlendingPlusMInusService>();
            services.TryAddTransient<ILineMaster, LineMasterServices>();
            services.TryAddTransient<IclVatTransfer, ClVatTransferService>();
            services.TryAddTransient<IProductionCommanData, ProductionCommanDataServices>();
            services.TryAddTransient<ISpritTransferIn, SpritTransferInServices>();
            services.TryAddTransient<IRSVATTransfer, RSVATTransferService>();
            services.TryAddTransient<ISpiritTransferOut, SpiritTransferOutService>();
            services.TryAddTransient<IProductionVatType, ProductionVatTypeServices>();
            services.TryAddTransient<IVatCalibrationMaster, VatCalibrationMasterServices>();
            services.TryAddTransient<IVatEntry, VatEntryServices>();
            services.TryAddTransient<IDSBalanceOpening, DSBalanceOpeningServices>();
            services.TryAddTransient<IFinishedGoodsOpeningStock, FinishedGoodsOpeningStockServices>();
            services.TryAddTransient<ILabModule, LabModuleServices>();
            services.TryAddTransient<ILabNormsMaster, LabNormsMasterServices>();
            services.TryAddTransient<IProductionCapacity, ProductionCapacityServices>();
            services.TryAddTransient<IDsSaleBill, DsSaleBillServices>();
            services.TryAddTransient<IRSSaleBill, RSSaleBillServices>();
            services.TryAddTransient<ILinkNOCForRs, LinkNOCForRsServices>();
            services.TryAddTransient<ISupplyScheduleIssuance, SupplyScheduleIssuanceServices>();
            services.TryAddTransient<IRawMaterialRequired, RawMaterialRequiredServices>();
            services.TryAddTransient<IRawMaterialGateEntry, RawMaterialGateEntryServices>();
            services.TryAddTransient<IProductionGateEntry, ProductionGateEntryService>();
            services.TryAddTransient<IVasselMaster, VasselMasterServices>();
            services.TryAddTransient<IVatLedgerDetails, VatLedgerDetailsServices>();
            services.TryAddTransient<IWashProduction, WashProductionServices>();
            services.TryAddTransient<IFermentation, FermentationServices>();
            services.TryAddTransient<IDailyProduction, DailyProductionServices>();
            services.TryAddTransient<ITankerDiversionOrder, TankerDiversionOrderServices>();

            #endregion

            #region Retail On Renewal
            services.TryAddTransient<ILicenseRenewal, LicenseRenewalServices>();
            #endregion

            #region DailyProduction
            services.TryAddTransient<IDailyProduction, DailyProductionServices>();
            services.TryAddTransient<ILabRegistration, LabRegistrationServices>();

            #endregion DailyProduction

            #region errorLog
            services.TryAddTransient<IErrorLog, ErrorLogServices>();
            services.TryAddTransient<IProductionGateEntry, ProductionGateEntryService>();
            services.TryAddTransient<IBusinessObject, BusinessObjectService>();
            services.TryAddTransient<IWSLicenseeRenewal, WSLicenseeRenewal>();


            services.TryAddTransient<ILicenseeMapping, LicenseeMappingServices>();
            services.TryAddTransient<IExciseRuleMapping, ExciseRuleMappingServices>();
            #endregion

            #region LicenseShopAndNokarnama
            services.TryAddTransient<IShopAllocationInterface, ShopAllocationServices>();
            services.TryAddTransient<INokarnamaInterface, NokarnamaServices>();
            #endregion

            #region Purchase
            services.TryAddTransient<INIBRepo, NIBService>();
            services.TryAddTransient<IDispatchNote, DispatchNoteService>();
            services.TryAddTransient<IPurOrder, POService>();
            services.TryAddTransient<IGroupMaster, GroupMasterServices>();
            services.TryAddTransient<IStoreGateEntry, StoreGateEntryService>();
            services.TryAddTransient<IItemDescription, GroupMasterItemDescriptonServices>();
            services.TryAddTransient<ISupplySchedule, SupplyScheduleService>();
            services.TryAddTransient<ILetterOfAcceptance, LOAService>();
            services.TryAddTransient<IPurchaseIssue, IssuePurchaseService>();
            services.TryAddTransient<IIndentProduction, IndentProductionService>();
            services.TryAddTransient<ISupplyScheduleIssuanceNoC, SupplyScheduleIssuanceService>();
            services.TryAddTransient<IGRS, GRSService>();
            services.TryAddTransient<IPurchaseOrderGeneration, PurchaseOrderGenerationService>();



            #endregion
            services.TryAddTransient<IEdistrictMaster, EDistrictMasterService>();
            services.TryAddTransient<IDistrictTreasury, DistrictTresauryService>();
            services.TryAddTransient<IDeptTreasuryMappingcs, DeptTreasuryServices>();
            services.TryAddTransient<IAddBarcounter, AddBarCounterService>();
            services.TryAddTransient<IVendorMaster, VendorMasterServices>();
            services.TryAddTransient<INormMaster, NormMasterService>();
            #region FLRequest
            services.TryAddTransient<ISCMRetailOffManual, SCMRetailOffManualService>();
            services.TryAddTransient<ISCMWholesaleDepo, SCMWholesaleDepoService>();
            #endregion
            #region EVC Entry
            services.TryAddTransient<IEVCEntry, EVCEntryService>();
            #endregion
            services.TryAddTransient<IEProcureBidderEntry, EProcureBidderEntryrepo>();

            #region CRM
            services.TryAddTransient<IAdminDashBoard, AdminDashBoardServices>();
            services.TryAddTransient<ICrmEntry, CrmEntryServices>();
            services.TryAddTransient<IDeoCiAcCRMDashBoard, DeoCiAcDashBoardServices>();
            services.TryAddTransient<IMasterComplaint, MasterComplaintServices>();
            services.TryAddTransient<IBakayaEntry, BakayaEntryServices>();
            services.TryAddTransient<IBakayaDeposit, BakayaDepositServices>();
            #endregion

            #region ITPVoucher
            services.TryAddTransient<IItpVoucher, ItpVoucherService>();
            #endregion
            services.TryAddTransient<IQueryWizard, QueryWizardService>();
            services.TryAddTransient<IBakayaDeposit, BakayaDepositServices>();
            services.TryAddTransient<ITicketSystem, TicketSystemServices>();
            services.TryAddTransient<IExciseShopMaster, ExciseShopMasterServices>();
            services.TryAddTransient<IMultipleSSOMapping, MultipleSSOMappingServices>();
            services.TryAddTransient<IUserProfile, UserProfileServices>();

            services.AddHttpContextAccessor();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            //builder.Services.AddDistributedMemoryCache();


            #region WorkFlow Master
            services.TryAddTransient<IWorkFlowOfficer, WorkFlowOfficerServices>();
            services.TryAddTransient<IOfficer, OfficerServices>();
            services.TryAddTransient<IManageWorkFlow, ManageWorkFlowServices>();
            services.TryAddTransient<IModuleRoleMapping, ModuleRoleMappingServices>();
            #endregion

            services.TryAddTransient<IRetailOffLicensee, RetailOffLicenseeServices>(); // levy managemnet
            services.TryAddTransient<IGodownFee, GodownFeeService>();  // levy managemnet
            services.TryAddTransient<IMasterMaker, MasterMakerService>();  // 
            services.TryAddTransient<IUnitCapicity, UnitCapicityServices>();  // added  by ayush 
            services.TryAddTransient<IMstRetailOnLienseeRenewalFeeType, MstRetailOnLicenseeRenewalFeeTypeServices>();
            services.TryAddTransient<IYearMaster, YearMasterService>();
            services.TryAddTransient<IWorkflowMoment, WorkflowMoment>();
            services.TryAddTransient<IStatusOfRateApproval, ApprovedBrandRateStatusServices>();
            services.TryAddTransient<ICommonExtension, CommonExtensionServices>();
            services.TryAddTransient<IRateApproval, RateApprovalRepo>();
            services.TryAddTransient<ISCMWholesaleDepo, SCMWholesaleDepoService>();
            services.TryAddTransient<ISupplierSchedule, SupplierScheduleService>();
            services.TryAddTransient<IRSGSMINDENT, RSGSMIndentServices>();
            services.TryAddTransient<IRSGSMINDENTRML, RSGSMIndentRMLServices>();
            services.TryAddTransient<IDepotLicensee, DepotLicenseeServices>();
            services.TryAddTransient<IIPaymentAdjustment, PaymentAdjustServices>();
            services.TryAddTransient<IRajNivesh, RajNiveshServices>();
            services.TryAddTransient<IRSBCLINDENT, RSBCLIndentServices>();
            services.TryAddTransient<IRawMaterialDemandRC, RawMaterialDemandRCServices>();



            services.TryAddTransient<IGoodsRejection, GoodsRejectionServices>();
            services.TryAddTransient<ISupplierInvoiceNoc, SupplierInvoiceNocService>();
            services.TryAddTransient<IGurantee, GuranteeServices>();
            services.TryAddTransient<ICorporateOffice, CorporateOfficeServices>();
            services.TryAddTransient<IManualBankIntegrationService, ManualBankIntegrationServices>();
            services.TryAddTransient<IBhangePermit, BhangPermitServices>();
            services.TryAddTransient<ICompositeProfile1, CompositeProfileServices>();
            services.TryAddTransient<ISalerSummary, SalerSummaryServices>();
            services.TryAddTransient<IReport, ReportService>();
            services.TryAddTransient<IComplaints, ComplaintsServices>();
            services.TryAddTransient<ILevelDesignation, LevelDesignationServices>();
            services.TryAddTransient<IIssuesCategory, IssuesCategoryServices>();
            services.TryAddTransient<ITOOCancellation, TOOCancellationServices>();
            services.TryAddTransient<IEGrassChallan, EGrassChallanService>();
            services.TryAddTransient<IOFSReport, OFSReportService>();
            services.TryAddTransient<IVatReportService, VatReportService>();
            services.TryAddTransient<ISaleAndExciseDutySummaryReportService, SaleAndExciseDutySummaryReportService>();
            services.TryAddTransient<IProductionReportService, ProductionReportServices>();

            services.TryAddTransient<IOccasionalReport, OccasionalReportService>();
            services.TryAddTransient<ITcsrateEntry, tcsrateentryservice>();
            services.TryAddTransient<IGstReports, GstReportsService>();
            services.TryAddTransient<IPurchaseReport, PurchaseReportServiceses>();
            #region Occasional Report

            services.TryAddTransient<IReportBankChallanRegister, ReportBankChallanRegisterService>();

            #endregion

            #region HELP

            services.TryAddTransient<IAPK, APKServices>();

            #endregion

            #region Brand Approval Report

            services.TryAddTransient<IBrandApprovalReport, BrandApprovalReportServices>();

            #endregion

            #region Dynamic Query

            services.TryAddTransient<IDynamicQuery, DynamicQueryServices>();
            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
            //services.AddScoped<IUrlHelper, UrlHelper>();


            #endregion
            services.TryAddTransient<IOfflineDDIndentItp, OfflineItpServices>();

            #region FIR
            services.TryAddTransient<IVehicleTypeMaster, VehicleTypeMasterServices>();
            services.TryAddTransient<ISection, SectionServices>();
            services.TryAddTransient<ICmFirGoodDetail, CmFirGoodDetailServices>();
            services.TryAddTransient<IFirRegistration, FirRegService>();
            services.TryAddTransient<IAccusedDetails, AccusedDetailsServices>();
            services.TryAddTransient<ISeizedVehicleDetails, SeizedVehicleDetailsServices>();
            services.TryAddTransient<IAcquiredArchitecturalMaterial, AcquiredArchitecturalMaterialService>();
            services.TryAddTransient<IFirAct, FirActServices>();
            #endregion

            #region Supplier Vat Payment process
            services.TryAddTransient<IVatPaymentProcess, VatPaymentProcess>();
            #endregion
            services.TryAddTransient<ISupplierBrandExport, SupplierBrandExportService>();

            #region SupplierDepotWiseSalesPeport
            services.AddScoped<ISupplierDepotWiseSalesPeportService, SupplierDepotWiseSalesPeportService>();

            #endregion



            #region Duty Summary Report

            services.TryAddTransient<IDutySummaryReports, DutySummaryReportServices>();

            #endregion

            services.TryAddTransient<ITntProductionReport, TntProductionReportService>();//deepak kumar
            #region CountryLiquorClosingStock

            services.TryAddTransient<ICountryLiquorClosingStockInventoryService, CountryLiquorClosingStockInventoryReportService>();//deepak kumar
            services.TryAddTransient<IDispatchnotecreation, Dispatchnotecreationservice>();

            #endregion

            #region TNT

            services.TryAddTransient<ITNT, TNTServices>();


            #endregion

            #region Loading@UnloadingReports 
            services.TryAddTransient<ILoadingUnloadingReports, LoadingUnloadingReportsServices>();
            #endregion

            #region GST vikash and chandan
            services.TryAddTransient<IGstTaxInvoice, GstTaxInvoiceService>();
            services.TryAddTransient<IGstDebitCreditNote, GstDebitCreditNoteService>();
            #endregion
            services.TryAddTransient<IUnit, UnitServices>();

            #region Amount Deposited By Licensee

            services.TryAddTransient<IAmountDepositedByLicensee, AmountDepositedByLicenseeServices>();

            #endregion

            return services;

        }
    }
}
