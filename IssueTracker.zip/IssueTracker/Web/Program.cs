
app.UseEndpoints(endpoints =>

{

    // Register area-specific routes

    var areaNames = builder.Configuration.GetSection("AreaNames").Get<List<string>>();

    foreach (var area in areaNames)

    {

        endpoints.MapAreaControllerRoute(

            name: $"{area}Route",

            areaName: area,

            pattern: $"{area}/{{controller=Home}}/{{action=Index}}"

        );

    }

    // Register general routes

    endpoints.MapControllerRoute(

        name: "areaRoute",

        pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}"

    );

    endpoints.MapControllerRoute(

        name: "default",

        pattern: "{controller=Login}/{action=HomeLanding}/{id?}"

    );

});



app.Run();
