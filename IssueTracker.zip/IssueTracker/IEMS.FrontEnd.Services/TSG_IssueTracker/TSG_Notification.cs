﻿using IEMS.FrontEnd.Common.Common;
using IEMS.FrontEnd.Interface.IssueTracker_TSG;
using IEMS.FrontEnd.Models.Common_TSG;
using IEMS.FrontEnd.Models.TSG_Notification.Notification.Payload;
using Newtonsoft.Json.Linq;

namespace IEMS.FrontEnd.Services.TSG_IssueTracker
{
    public class TSG_Notification : ITSG_Notification
    {
        public async Task<ApiResponse<object>> getGrievanceRegistrationData(GrievanceDataPayload reqModel)
        {
            ApiResponse<object> objRes = null;
            using (var client = new HttpClient())
            {
                try
                {
                    #region Call API 
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(reqModel);
                    var jsonObject = JsonConvert.DeserializeObject<JToken>(json);
                    JsonCommonFunctions.ReplaceNullsWithEmptyStrings(jsonObject);
                    string updatedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                    string url = URLPORTServices.GetURL(URLPORT.IssueTracker_TSG);
                    string APIkey = URLPORTServices.GetAPIKey(TSGAPIKEY.IssueTracker_TSG);
                    string req = url + String.Format(TSGApiConfig.GETGRIEVANCEREGISTRATION);
                    var response = await HttpClientHelper.POSTAPITSG(req, updatedJson, "", APIkey);
                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        objRes = JsonConvert.DeserializeObject<ApiResponse<object>>(data);
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                return objRes;
            }
        }
        public async Task<ApiResponse<object>> getGrievanceRegistrationListFilterData(GrievanceRegistrationPayload reqModel)
        {
            ApiResponse<object> objRes = null;
            using (var client = new HttpClient())
            {
                try
                {
                    #region Call API 
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(reqModel);
                    var jsonObject = JsonConvert.DeserializeObject<JToken>(json);
                    JsonCommonFunctions.ReplaceNullsWithEmptyStrings(jsonObject);
                    string updatedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                    string url = URLPORTServices.GetURL(URLPORT.IssueTracker_TSG);
                    string APIkey = URLPORTServices.GetAPIKey(TSGAPIKEY.IssueTracker_TSG);
                    string req = url + String.Format(TSGApiConfig.GETGRIEVANCEREGISTRATION);
                    var response = await HttpClientHelper.POSTAPITSG(req, updatedJson, "", APIkey);
                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        objRes = JsonConvert.DeserializeObject<ApiResponse<object>>(data);
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                return objRes;
            }
        }
        public async Task<ApiResponse<object>> getGrievanceWorkFlowAction(GrievanceWorkFlowPayload reqModel)
        {
            ApiResponse<object> objRes = null;
            using (var client = new HttpClient())
            {
                try
                {
                    #region Call API 
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(reqModel);
                    var jsonObject = JsonConvert.DeserializeObject<JToken>(json);
                    JsonCommonFunctions.ReplaceNullsWithEmptyStrings(jsonObject);
                    string updatedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                    string url = URLPORTServices.GetURL(URLPORT.IssueTracker_TSG);
                    string APIkey = URLPORTServices.GetAPIKey(TSGAPIKEY.IssueTracker_TSG);
                    string req = url + String.Format(TSGApiConfig.GetGrievanceWorkFlowAction);
                    var response = await HttpClientHelper.POSTAPITSG(req, updatedJson, "", APIkey);
                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        objRes = JsonConvert.DeserializeObject<ApiResponse<object>>(data);
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                return objRes;
            }
        }
        public async Task<ApiResponse<object>> getUserMGMasterData(MasterDropDownInput reqModel)
        {
            ApiResponse<object> objRes = null;
            using (var client = new HttpClient())
            {
                try
                {
                    #region Call API 
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(reqModel);
                    var jsonObject = JsonConvert.DeserializeObject<JToken>(json);
                    JsonCommonFunctions.ReplaceNullsWithEmptyStrings(jsonObject);
                    string updatedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                    string url = URLPORTServices.GetURL(URLPORT.UserManagement_TSG);
                    string APIkey = URLPORTServices.GetAPIKey(TSGAPIKEY.UserManagement_TSG);
                    string req = url + String.Format(TSGApiConfig.GetUserMGMasterDataDropDown);
                    var response = await HttpClientHelper.POSTAPITSG(req, updatedJson, "", APIkey);
                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        objRes = JsonConvert.DeserializeObject<ApiResponse<object>>(data);
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                return objRes;
            }
        }
        public async Task<ApiResponse<object>> updateStatusGrievance(UpdateStatusGrievancePayload reqModel)
        {
            ApiResponse<object> objRes = null;
            using (var client = new HttpClient())
            {
                try
                {
                    #region Call API 
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(reqModel);
                    var jsonObject = JsonConvert.DeserializeObject<JToken>(json);
                    JsonCommonFunctions.ReplaceNullsWithEmptyStrings(jsonObject);
                    string updatedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                    string url = URLPORTServices.GetURL(URLPORT.IssueTracker_TSG);
                    string APIkey = URLPORTServices.GetAPIKey(TSGAPIKEY.IssueTracker_TSG);
                    string req = url + String.Format(TSGApiConfig.UpdateStatusGrievance);
                    var response = await HttpClientHelper.POSTAPITSG(req, updatedJson, "", APIkey);
                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        objRes = JsonConvert.DeserializeObject<ApiResponse<object>>(data);
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                return objRes;
            }
        }
        public async Task<ApiResponse<object>> getGrievanceUserAction(GrievanceUserActionPayload reqModel)
        {
            ApiResponse<object> objRes = null;
            using (var client = new HttpClient())
            {
                try
                {
                    #region Call API 
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(reqModel);
                    var jsonObject = JsonConvert.DeserializeObject<JToken>(json);
                    JsonCommonFunctions.ReplaceNullsWithEmptyStrings(jsonObject);
                    string updatedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                    string url = URLPORTServices.GetURL(URLPORT.IssueTracker_TSG);
                    string APIkey = URLPORTServices.GetAPIKey(TSGAPIKEY.IssueTracker_TSG);
                    string req = url + String.Format(TSGApiConfig.GetGrievanceUserAction);
                    var response = await HttpClientHelper.POSTAPITSG(req, updatedJson, "", APIkey);
                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        objRes = JsonConvert.DeserializeObject<ApiResponse<object>>(data);
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                return objRes;
            }
        }
        public async Task<ApiResponse<object>> SendSMS(SendSMSPayload reqModel)
        {
            ApiResponse<object> objRes = null;
            using (var client = new HttpClient())
            {
                try
                {
                    #region Call API 
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(reqModel);
                    var jsonObject = JsonConvert.DeserializeObject<JToken>(json);
                    JsonCommonFunctions.ReplaceNullsWithEmptyStrings(jsonObject);
                    string updatedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                    string url = URLPORTServices.GetURL(URLPORT.MessageBus_TSG);
                    string APIkey = URLPORTServices.GetAPIKey(TSGAPIKEY.MessageBus_TSG);
                    string req = url + String.Format(TSGApiConfig.IEMSSendSMS);
                    var response = await HttpClientHelper.POSTAPITSG(req, updatedJson, "", APIkey);
                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        objRes = JsonConvert.DeserializeObject<ApiResponse<object>>(data);
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                return objRes;
            }
        }
        public async Task<ApiResponse<object>> getGrievanceCount(GrievanceCountPayload reqModel)
        {
            ApiResponse<object> objRes = null;
            using (var client = new HttpClient())
            {
                try
                {
                    #region Call API 
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(reqModel);
                    var jsonObject = JsonConvert.DeserializeObject<JToken>(json);
                    JsonCommonFunctions.ReplaceNullsWithEmptyStrings(jsonObject);
                    string updatedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                    string url = URLPORTServices.GetURL(URLPORT.IssueTracker_TSG);
                    string APIkey = URLPORTServices.GetAPIKey(TSGAPIKEY.IssueTracker_TSG);
                    string req = url + String.Format(TSGApiConfig.GetGrievanceCount);
                    var response = await HttpClientHelper.POSTAPITSG(req, updatedJson, "", APIkey);
                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        objRes = JsonConvert.DeserializeObject<ApiResponse<object>>(data);
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                return objRes;
            }
        }
        public async Task<ApiResponse<object>> getGrievanceCountDetail(GrievanceCountDetailPayload reqModel)
        {
            ApiResponse<object> objRes = null;
            using (var client = new HttpClient())
            {
                try
                {
                    #region Call API 
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(reqModel);
                    var jsonObject = JsonConvert.DeserializeObject<JToken>(json);
                    JsonCommonFunctions.ReplaceNullsWithEmptyStrings(jsonObject);
                    string updatedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                    string url = URLPORTServices.GetURL(URLPORT.IssueTracker_TSG);
                    string APIkey = URLPORTServices.GetAPIKey(TSGAPIKEY.IssueTracker_TSG);
                    string req = url + String.Format(TSGApiConfig.GetGrievanceCountDetail);
                    var response = await HttpClientHelper.POSTAPITSG(req, updatedJson, "", APIkey);
                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        objRes = JsonConvert.DeserializeObject<ApiResponse<object>>(data);
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                return objRes;
            }
        }
    }
}
