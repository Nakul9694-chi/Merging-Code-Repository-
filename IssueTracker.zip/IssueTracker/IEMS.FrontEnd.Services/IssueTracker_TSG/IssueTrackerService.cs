﻿using IEMS.FrontEnd.Common.Common;
using IEMS.FrontEnd.Interface.IssueTracker_TSG;
using IEMS.FrontEnd.Interface.Purchase_TSG;
using IEMS.FrontEnd.Models.Common_TSG;
using IEMS.FrontEnd.Models.IssueTracker_TSG.Register;
using IEMS.FrontEnd.Models.IssueTracker_TSG.RegisterVM;
using IEMS.FrontEnd.Models.Purchase_TSG;
using IEMS.FrontEnd.Models.RateApproval;
using IEMS.FrontEnd.Models.ResponseModel;
using IEMS.FrontEnd.Models.TSG_Notification.Notification.Payload;
using IEMS.FrontEnd.Models.Wallet.Response;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace IEMS.FrontEnd.Services.IssueTracker_TSG
{

    public class IssueTrackerService : IIssueTracker
    {
        ModuleApiKeyTSG ModuleApiKeyTSG = new ModuleApiKeyTSG();
        
        public async Task<MasterDropDown> GetDepartmentList(string UserID)
        {

            MasterDropDown model = new MasterDropDown();
            using (var client = new HttpClient())
            {
                try
                {
                    #region Call API 
                    string url = URLPORTServices.GetURL(URLPORT.Login);
                    var response = await HttpClientHelper.GetAPI(url + String.Format("BusinessObject/GetBoList?UserID={0}", 17572), "");

                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        model = Newtonsoft.Json.JsonConvert.DeserializeObject<MasterDropDown>(data);
                    }
                    else
                    {
                        //model.Status = -1;
                        //model.Message = "Something Went Wrong....";
                    }
                }
                catch (Exception ex)
                {

                }
                return model;
            }
        }


        public async Task<ApiResponse<object>> GetGrievanceWorkFlowAction(GrievanceWorkFlowPayload grievanceWorkFlowPayload)
        {
            ApiResponse<object> objRes = null;
            using (var client = new HttpClient())
            {
                try
                {
                    #region Call API 
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(grievanceWorkFlowPayload);
                    var jsonObject = JsonConvert.DeserializeObject<JToken>(json);
                    JsonCommonFunctions.ReplaceNullsWithEmptyStrings(jsonObject);
                    string updatedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                    string url = URLPORTServices.GetURL(URLPORT.IssueTracker_TSG);
                    string APIkey = URLPORTServices.GetAPIKey(TSGAPIKEY.IssueTracker_TSG);
                    string req = url + String.Format(TSGApiConfig.GETGRIEVANCEWORKFLOWACTION);
                    var response = await HttpClientHelper.POSTAPITSG(req, updatedJson, "", APIkey);
                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        objRes = JsonConvert.DeserializeObject<ApiResponse<object>>(data);
                      
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                return objRes;
            }
        }


        public async Task<ApiResponse<object>> SaveIssueTracker(IssueTrackerModel vm)
        {
            ApiResponse<object> objRes = null;
            using (var client = new HttpClient())
            {
                try
                {
                    //StreamContent fileContent;
                    #region Call API 
                    //var fileContent;
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(vm);                   
                    var jsonObject = JsonConvert.DeserializeObject<JToken>(json);
                    JsonCommonFunctions.ReplaceNullsWithEmptyStrings(jsonObject);
                    string updatedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                    string url = URLPORTServices.GetURL(URLPORT.IssueTracker_TSG);
                    string APIkey = URLPORTServices.GetAPIKey(TSGAPIKEY.IssueTracker_TSG);
                    string req = url + String.Format(TSGApiConfig.SAVEGRIEVANCEREGISTRATION);   
                    var response = await HttpClientHelper.POSTFORMDATATSG(req, updatedJson, "", APIkey, vm.formFile);
                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        objRes = JsonConvert.DeserializeObject<ApiResponse<object>>(data);
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                return objRes;
            }
        }

        public async Task<ApiResponse<object>> UpdateIssueTracker(IssueTrackerModel vm)
        {
            ApiResponse<object> objRes = null;
            using (var client = new HttpClient())
            {
                try
                {
                    #region Call API 
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(vm);
                    string fileName = vm.formFileName;
                    string filePath = vm.formFilePath;
                    var jsonObject = JsonConvert.DeserializeObject<JToken>(json);
                    JsonCommonFunctions.ReplaceNullsWithEmptyStrings(jsonObject);
                    string updatedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                    string url = URLPORTServices.GetURL(URLPORT.IssueTracker_TSG);
                    string APIkey = URLPORTServices.GetAPIKey(TSGAPIKEY.IssueTracker_TSG);
                    string req = url + String.Format(TSGApiConfig.UPDATEGRIEVANCEREGISTRATION);
                    var response = await HttpClientHelper.POSTFORMDATATSG(req, updatedJson, "", APIkey, vm.formFile);
                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        objRes = JsonConvert.DeserializeObject<ApiResponse<object>>(data);
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                return objRes;
            }
        }

        public async Task<ApiResponse<object>> GetSSODetail(string SSOID)
        {
            ApiResponse<object> objRes = null;
            using (var client = new HttpClient())
            {
                try
                {
                    #region Call API                    
                    string url = URLPORTServices.GetURL(URLPORT.IssueTracker_TSG);
                    string APIkey = URLPORTServices.GetAPIKey(TSGAPIKEY.IssueTracker_TSG);
                    string req = url + String.Format(TSGApiConfig.SSOGetUserDetail, SSOID);
                    var response = await HttpClientHelper.GetAPITSG(req, "", "", APIkey);
                    #endregion
                    if (response != null)
                    {
                        var data = await response.Content.ReadAsStringAsync();
                        objRes = JsonConvert.DeserializeObject<ApiResponse<object>>(data);

                    }
                    else
                    {
                        objRes.Status = -1;
                        objRes.Message = "Something Went Wrong....";
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                return objRes;
            }

        }
    }


}
