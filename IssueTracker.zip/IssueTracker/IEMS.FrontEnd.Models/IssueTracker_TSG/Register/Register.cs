﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEMS.FrontEnd.Models.IssueTracker_TSG.Register
{
    public class Register
    {
    }
    public class MasterDropDownInput
    {
        public int id { get; set; }
        public string action { get; set; }
        public int iS_ACTIVE { get; set; }

    }
    public class MasterDropDown
    {
        public int BoId { get; set; }
        public string BoName { get; set; }
        public string BoCode { get; set; }
        public List<List> List { get; set; }

    }
    public class List
    {
        public int BoId { get; set; }
        public string BoName { get; set; }
        public string BoCode { get; set; }
    }

    public class IssueTrackerModel
    {
        public string SSOID { get; set; }
        [Required(ErrorMessage = "Name is required.")]
        [StringLength(100, ErrorMessage = "Maxium 100 Character is allowed.")]
        [RegularExpression(@"^\S.*$", ErrorMessage = "Name cannot start with a space.")]
        public string NAME { get; set; }
        [Required(ErrorMessage = "Mobile Number is required.")]
        [RegularExpression(@"^[6-9]\d{9}$", ErrorMessage = "Enter valid 10 digit mobile number.")]
        public long MOBILE_NUMBER { get; set; }
        public string DESIGNATION { get; set; }
        [Required(ErrorMessage = "Please select a Department.")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select a valid Department.")]
        public int DEPT_ID { get; set; }
        [Required(ErrorMessage = "Please select a Module.")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select a valid Module.")]
        public int MODULE_ID { get; set; }
        [Required(ErrorMessage = "Please select a SubModule.")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select a valid SubModule.")]
        public int SUB_MODULE_ID { get; set; }
        public int STATUS_ID { get; set; }
        public int USER_ID { get; set; }
        public int DESTINATION_USER_ID { get; set; }
        public int SOURCE_ROLE_ID { get; set; }
        public int DESTINATION_ROLE_ID { get; set; }
        public int SOURCE_STAGE_ID { get; set; }
        public int DESTINATION_STAGE_ID { get; set; }
        public int ACTION_ID { get; set; }
        public int AUDIT_ID { get; set; }
        public string CREATED_BY { get; set; }
        public string GRIEVANCE_ID { get; set; }
        public int GR_ID { get; set; }
      
        [Required(ErrorMessage = "Description is required.")]
        [StringLength(3000, ErrorMessage = "Maxium 3000 Character is allowed.")]
        [RegularExpression(@"^(?!\s).*", ErrorMessage = "Description should not start with a space.")]
        public string DESCRIPTION { get; set; }

        public string USER_COMMENT { get; set; }
        public string MODIFIED_BY { get; set; }
        public int PROJECT_ID { get; set; }

        public IFormFile formFile  { get; set; }
        public string formFileName { get; set; }
        public string formFilePath { get; set; }
        public string UPLOAD_FILES { get; set; }

    }
    public class GrievanceWorkFlowAction
    {
        public string ACTION { get; set; }
        public int PROJECT_ID { get; set; }
        public int SOURCE_STAGE_ID { get; set; }
        public int SOURCE_ROLE_ID { get; set; }
    }
    public class GrievanceWorkFlowActionResponse
    {
        public string ACTION_NAME { get; set; }
        public int ACTION_ID { get; set; }
        public int SOURCE_STAGE_ID { get; set; }
        public int DESTINATION_STAGE_ID { get; set; }
        public int DESTINATION_ROLE_ID { get; set; }
        public int STATUS_ID { get; set; }
        public string STATUS { get; set; }
    }
    public class GrievanceResponse
    {
        public int ID { get; set; }
        public string  MSG { get; set; }
        public string GRIEVANCE_ID { get; set; }
        public int PROJECT_ID { get; set; }
        public int ACTION_ID { get; set; }
        public string SMSTEMPLATE_ID { get; set; }
        public string MOBILE_NUMBER { get; set; }
        public string TEMPLATEMESSAGE { get; set; }
    }

    public class SSOData
    {
        public string ssoid { get; set; }
        public string displayName { get; set; }
        public string designation { get; set; }
        public string mobile { get; set; }
    }

}
