﻿using IEMS.FrontEnd.Models.IssueTracker_TSG.Register;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEMS.FrontEnd.Models.IssueTracker_TSG.RegisterVM
{
    public class RegisterViewModel
    {
        public IssueTrackerModel ITModel { get; set; }
        //public List<SelectListItem> CategoryList { get; set; }
        //public List<SelectListItem> SubCategoryList { get; set; }
    }
}
