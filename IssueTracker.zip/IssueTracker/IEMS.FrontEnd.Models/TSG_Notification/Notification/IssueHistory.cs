﻿using IEMS.FrontEnd.Models.TSG_Notification.Notification.Payload;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEMS.FrontEnd.Models.TSG_Notification.Notification
{
    public class IssueHistory
    {
        public List<GrievanceData> GrievanceGetBasicDataModel { get; set; }
        public List<GrievanceTrail> GrievanceTrailModel { get; set; }
    }


}
