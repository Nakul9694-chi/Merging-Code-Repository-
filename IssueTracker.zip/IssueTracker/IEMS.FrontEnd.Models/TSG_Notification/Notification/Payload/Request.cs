﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEMS.FrontEnd.Models.TSG_Notification.Notification.Payload
{
    public class Request
    {
    }
    public class GrievanceRegistrationPayload
    {
        public string ACTION { get; set; }
        public string SSOID { get; set; }
        public int ROLE_ID { get; set; }
        public int GR_ID { get; set; }
        public int USER_ID { get; set; }
        public string FROM_DATE { get; set; }
        public string TO_DATE { get; set; }
        public int? STATUS_ID { get; set; }
    }

    public class GrievanceDataPayload
    {
        public string ACTION { get; set; }
        public string SSOID { get; set; }
        public int ROLE_ID { get; set; }
        public int GR_ID { get; set; }
        public int USER_ID { get; set; }
    }
    public class UpdateStatusGrievancePayload
    {
        public int GR_ID { get; set; }
        public string GRIEVANCE_ID { get; set; }
        public int STATUS_ID { get; set; }
        public int USER_ID { get; set; }
        public int DESTINATION_USER_ID { get; set; }
        public int SOURCE_ROLE_ID { get; set; }
        public int DESTINATION_ROLE_ID { get; set; }
        public int SOURCE_STAGE_ID { get; set; }
        public int DESTINATION_STAGE_ID { get; set; }
        public string USER_COMMENT { get; set; }
        public int ACTION_ID { get; set; }
        public int AUDIT_ID { get; set; }
        public string MODIFIED_BY { get; set; }
        public int PROJECT_ID { get; set; }
    }

    public class SendSMSPayload
    {
        public int? transactionId { get; set; }
        public int? project_ID { get; set; }
        public int? action_ID { get; set; }
        public string templateId { get; set; }
        public string mobileNumber { get; set; }
        public string templateSMS { get; set; }
    }


    public class GrievanceWorkFlowPayload
    {
        public string ACTION { get; set; }
        public int PROJECT_ID { get; set; }
        public int SOURCE_ROLE_ID { get; set; }
        public int SOURCE_STAGE_ID { get; set; }
    }

    public class MasterDropDownInput
    {
        public int Id { get; set; }
        public string Action { get; set; }
        public int IsActive { get; set; }
    }

    public class GrievanceUserActionPayload
    {
        public string ACTION { get; set; }
        public string SSOID { get; set; }
        public int ROLE_ID { get; set; }
        public int MODULE_ID { get; set; }
        public int SUBMODULE_ID { get; set; }
    }

    public class GrievanceCountPayload
    {
        public int DEPT_ID { get; set; }
        public int MODULE_ID { get; set; }
        public int SUB_MODULE_ID { get; set; }
        public string FROM_DATE { get; set; }
        public string TO_DATE { get; set; }
    }
    public class GrievanceCountDetailPayload
    {
        public int DEPT_ID { get; set; }
        public int MODULE_ID { get; set; }
        public int SUB_MODULE_ID { get; set; }
        public string FROM_DATE { get; set; }
        public string TO_DATE { get; set; }
        public string REPORT_ACTION { get; set; }
    }
}
