﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEMS.FrontEnd.Models.TSG_Notification.Notification.Payload
{
    public class Response
    {
    }

    public class GrievanceRegistrationData
    {
        public string GRIEVANCE_ID { get; set; }
        public int GR_ID { get; set; }
        public string SSOID { get; set; }
        public string NAME { get; set; }
        public string MOBILE_NUMBER { get; set; }
        public string DESIGNATION { get; set; }
        public int DEPT_ID { get; set; }
        public string DEPT_NAME { get; set; }
        public string SEVERITY_NAME { get; set; }
        public string UPLOAD_FILES { get; set; }
        public int STATUS_ID { get; set; }
        public string STATUS { get; set; }
        public string DESCRIPTION { get; set; }
        public int MODULE_ID { get; set; }
        public string MODULE_NAME { get; set; }
        public int SUB_MODULE_ID { get; set; }
        public string SUB_MODULE_NAME { get; set; }
        public string CREATED_DATE { get; set; }
        public int SOURCE_STAGE_ID { get; set; }
        public int AUDIT_ID { get; set; }
        public int ISEDIT { get; set; }
        public string USER_COMMENT { get; set; }
        public string PERFORMED_ACTION { get; set; }
        public string PERFORMED_ACTION_REMARKS { get; set; }
        public string PERFORMED_ACTION_BY { get; set; }
        public string PERFORMED_USER_ROLE_NAME { get; set; }
        public string PERFORMED_ACTION_DATE { get; set; }
        public string GRIEVANCE_CREATED_DATE { get; set; }
        public int DESTINATION_USER_ID { get; set; }
        public int CITIZEN_USER_ID { get; set; }
        public int ISRESOLVED { get; set; }
        public object SOURCE_ROLE_NAME { get; set; }
        public string PENDING_AT { get; set; }
        public string PENDING_DAYS { get; set; }
    }

    public class GrievanceData
    {
        public string GRIEVANCE_ID { get; set; }
        public int? GR_ID { get; set; }
        public string SSOID { get; set; }
        public string NAME { get; set; }
        public string MOBILE_NUMBER { get; set; }
        public string DESIGNATION { get; set; }
        public int? DEPT_ID { get; set; }
        public string DEPT_NAME { get; set; }
        public string SEVERITY_NAME { get; set; }
        public string UPLOAD_FILES { get; set; }
        public int? STATUS_ID { get; set; }
        public string STATUS { get; set; }
        public string DESCRIPTION { get; set; }
        public int? MODULE_ID { get; set; }
        public string MODULE_NAME { get; set; }
        public int? SUB_MODULE_ID { get; set; }
        public string SUB_MODULE_NAME { get; set; }
        public string CREATED_DATE { get; set; }
        public int? SOURCE_STAGE_ID { get; set; }
        public int? AUDIT_ID { get; set; }
        public int? ISEDIT { get; set; }
        public string USER_COMMENT { get; set; }
        public string PERFORMED_ACTION { get; set; }
        public string PERFORMED_ACTION_REMARKS { get; set; }
        public string PERFORMED_ACTION_BY { get; set; }
        public string PERFORMED_USER_ROLE_NAME { get; set; }
        public string PERFORMED_ACTION_DATE { get; set; }
        public string GRIEVANCE_CREATED_DATE { get; set; }
        public int? DESTINATION_USER_ID { get; set; }
        public int? CITIZEN_USER_ID { get; set; }
        public int? ISRESOLVED { get; set; }
        public string SOURCE_ROLE_NAME { get; set; }
        public string PENDING_AT { get; set; }
        public string PENDING_DAYS { get; set; }
    }

    public class GrievanceTrail
    {
        public string GRIEVANCE_ID { get; set; }
        public int GR_ID { get; set; }
        public object SSOID { get; set; }
        public object NAME { get; set; }
        public object MOBILE_NUMBER { get; set; }
        public object DESIGNATION { get; set; }
        public object DEPT_ID { get; set; }
        public string DEPT_NAME { get; set; }
        public string SEVERITY_NAME { get; set; }
        public string UPLOAD_FILES { get; set; }
        public object STATUS_ID { get; set; }
        public string STATUS { get; set; }
        public string DESCRIPTION { get; set; }
        public object MODULE_ID { get; set; }
        public string MODULE_NAME { get; set; }
        public object SUB_MODULE_ID { get; set; }
        public string SUB_MODULE_NAME { get; set; }
        public object CREATED_DATE { get; set; }
        public object SOURCE_STAGE_ID { get; set; }
        public object AUDIT_ID { get; set; }
        public object ISEDIT { get; set; }
        public string USER_COMMENT { get; set; }
        public string PERFORMED_ACTION { get; set; }
        public object PERFORMED_ACTION_REMARKS { get; set; }
        public string PERFORMED_ACTION_BY { get; set; }
        public string PERFORMED_USER_ROLE_NAME { get; set; }
        public string PERFORMED_ACTION_DATE { get; set; }
        public string GRIEVANCE_CREATED_DATE { get; set; }
        public object DESTINATION_USER_ID { get; set; }
        public object CITIZEN_USER_ID { get; set; }
        public object ISRESOLVED { get; set; }
        public object SOURCE_ROLE_NAME { get; set; }
        public object PENDING_AT { get; set; }
        public object PENDING_DAYS { get; set; }
    }

    public class GrievanceWorkFlowAction
    {
        public string ACTION_NAME { get; set; }
        public int ACTION_ID { get; set; }
        public int SOURCE_STAGE_ID { get; set; }
        public int DESTINATION_STAGE_ID { get; set; }
        public int DESTINATION_ROLE_ID { get; set; }
        public int STATUS_ID { get; set; }
        public string STATUS { get; set; }
    }

    public class UpdateStatusGrievanceResponse
    {
        public int? ID { get; set; }
        public string MSG { get; set; }
        public string GRIEVANCE_ID { get; set; }
        public int? PROJECT_ID { get; set; }
        public int? ACTION_ID { get; set; }
        public string SMSTEMPLATE_ID { get; set; }
        public string MOBILE_NUMBER { get; set; }
        public string TEMPLATEMESSAGE { get; set; }
    }

    public class SentSMSResponse
    {
        public int statusCode { get; set; }
        public int status { get; set; }
        public string message { get; set; }
        public string response { get; set; }
    }
    public class GrievanceUserActionResponse
    {
        public int USER_ID { get; set; }
        public string FULL_NAME { get; set; }
    }

    public class DrillDownRequestModel
    {
        public string Row { get; set; }
        public string Type { get; set; }
    }
    public class GrievanceCountResponse
    {
        public int DEPT_ID { get; set; }
        public int MODULE_ID { get; set; }
        public int SUB_MODULE_ID { get; set; }
        public string FROM_DATE { get; set; }
        public string TO_DATE { get; set; }
        public int? SEVERITY_ID { get; set; }
        public string REPORT_ACTION { get; set; }
        public string TOTAL_GRIEVANCE_REGISTERED { get; set; }
        public string TOTAL_GRIEVANCE_RESOLVED { get; set; }
        public string TOTAL_GRIEVANCE_PENDING { get; set; }
        public string RESOLUTION_RATE { get; set; }
        public string TOTAL_RESOLUTION_MINUTES { get; set; }
        public string TOTAL_RESOLUTION_HOURS { get; set; }
        public string TOTAL_RESOLUTION_DAYS_HOURS { get; set; }
    }

    public class GrievanceCountDetailResponse
    {
        public int GR_ID { get; set; }
        public string GRIEVANCE_ID { get; set; }
        public int DEPT_ID { get; set; }
        public string DEPT_NAME { get; set; }
        public int MODULE_ID { get; set; }
        public string MODULE_NAME { get; set; }
        public int SUB_MODULE_ID { get; set; }
        public string SUB_MODULE_NAME { get; set; }
        public string SEVERITY_NAME { get; set; }
        public string CREATED_DATE { get; set; }
        public string STATUS { get; set; }
        public string PENDING_AT { get; set; }
    }

}
