﻿using IEMS.FrontEnd.Models.TSG_Notification.Notification.Payload;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using static IEMS.FrontEnd.Models.TSG_Notification.Notification.IssuesModel;

namespace IEMS.FrontEnd.Models.TSG_Notification.Notification
{

    public class IssueViewModel
    {
        public IssueFilter Filter { get; set; } = new IssueFilter();
        public string SearchKey { get; set; }
        public List<GrievanceRegistrationData> Issues { get; set; } = new List<GrievanceRegistrationData>();
        //public List<Issue> Issues { get; set; } = new List<Issue>();
        public List<StatusOption> GrievanceStatus { get; set; } = new List<StatusOption>();
        public List<GrievanceWorkFlowAction> GrievanceWorkflowActions { get; set; } = new List<GrievanceWorkFlowAction>();

    }


    public class Issue
    {
        public int Id { get; set; }
        public string GrievanceId { get; set; }
        public string SeverityName { get; set; }
        public string SsoId { get; set; }
        public string Status { get; set; }
        public string PendingAt { get; set; }
        public int PendingDays { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class WorkflowAction
    {
        public string ActionName { get; set; }
    }

    public class RenderModel
    {
        public string actionName { get; set; }
        public int actionId { get; set; }
        public int destinationStageId { get; set; }
        public int destinationRoleId { get; set; }
        public int statusId { get; set; }
        public string status { get; set; }
        public int sourceStageId { get; set; }
        public int grId { get; set; }
        public string grievanceId { get; set; }
        public int auditId { get; set; }
        public int destinationUserId { get; set; }
        public int moduleId { get; set; }
        public int subModuleId { get; set; }
        public int citizenUserId { get; set; }
    }

    public class RenderViewModel
    {
        public string actionName { get; set; }
        public int actionId { get; set; }
        public int destinationStageId { get; set; }
        public int destinationRoleId { get; set; }
        public int statusId { get; set; }
        public string status { get; set; }
        public int sourceStageId { get; set; }
        public int grId { get; set; }
        public string grievanceId { get; set; }
        public int auditId { get; set; }
        public int destinationUserId { get; set; }
        public int moduleId { get; set; }
        public int subModuleId { get; set; }
        public int citizenUserId { get; set; }

        [Required(ErrorMessage = "Please select a user to forward to.")]
        public int? ForwardTo { get; set; }
        public List<StatusList> statusList { get; set; }
        public List<GrievanceUserActionResponse> UserActionList { get; set; }
        public string ClarificationDetails { get; set; }
    }

    public class StatusList
    {
        public int statusId { get; set; }
        public string status { get; set; }
    }
    public class IssuesModel : PageModel
    {
        [BindProperty]
        public IssueFilter Filter { get; set; } = new();

        [BindProperty]
        public string SearchKey { get; set; } = "";

        public List<Issue> Issues { get; set; } = new();

        public List<Issue> FilteredIssues { get; set; } = new();

        public List<StatusOption> GrievanceStatus { get; set; } = new()
        {
            new StatusOption { Id = "1", FullName = "Open" },
            new StatusOption { Id = "2", FullName = "In Progress" },
            new StatusOption { Id = "3", FullName = "Closed" }
        };

        public List<WorkflowAction> GrievanceWorkflowActions { get; set; } = new()
        {
            new WorkflowAction { ActionName = "Delegate" },
            new WorkflowAction { ActionName = "Resolved" },
            new WorkflowAction { ActionName = "Clarification" },
            new WorkflowAction { ActionName = "Forward" }
        };

        public void OnGet()
        {
            LoadIssues();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                LoadIssues();
                return Page();
            }

            LoadIssues();
            return Page();
        }

        public IActionResult OnPostExportToExcel()
        {
            // TODO: Export to Excel logic here
            return Page();
        }

        public IActionResult OnPostExportToPDF()
        {
            // TODO: Export to PDF logic here
            return Page();
        }

        public IActionResult OnPostActionSelected(int issueId, string actionName)
        {
            // TODO: Handle action selected on issue
            TempData["Message"] = $"Action '{actionName}' selected for issue {issueId}";
            return RedirectToPage();
        }

        private void LoadIssues()
        {
            // Mock data for demo purposes
            Issues = new List<Issue>
            {
                new Issue { Id = 1, GrievanceId = "G001", SeverityName = "HIGHER", SsoId = "SSO123", Status = "Open", PendingAt = "Dept A", PendingDays = 5, CreatedDate = DateTime.Now.AddDays(-10)},
                new Issue { Id = 2, GrievanceId = "G002", SeverityName = "MEDIUM", SsoId = "SSO456", Status = "In Progress", PendingAt = "Dept B", PendingDays = 3, CreatedDate = DateTime.Now.AddDays(-7)},
                new Issue { Id = 3, GrievanceId = "G003", SeverityName = "LOWER", SsoId = "SSO789", Status = "Closed", PendingAt = "Dept C", PendingDays = 0, CreatedDate = DateTime.Now.AddDays(-1)},
            };
        }

        public class IssueFilter
        {
            [Required(ErrorMessage = "From Date is required")]
            [DataType(DataType.Date)]
            public DateTime? DateFrom { get; set; }

            [Required(ErrorMessage = "To Date is required")]
            [DataType(DataType.Date)]
            public DateTime? DateTo { get; set; }

            public string Status { get; set; }
        }

        public class StatusOption
        {
            public string Id { get; set; }
            public string FullName { get; set; }
        }

    }
}
