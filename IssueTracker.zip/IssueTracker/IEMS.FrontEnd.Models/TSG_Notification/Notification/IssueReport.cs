﻿using IEMS.FrontEnd.Models.TSG_Notification.Notification.Payload;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using static IEMS.FrontEnd.Models.TSG_Notification.Notification.IssuesModel;

namespace IEMS.FrontEnd.Models.TSG_Notification.Notification
{
    public class IssueReport
    {
    }

    public class IssueReportFilterViewModel
    {
        [Required(ErrorMessage = "Department is required")]
        public int DepartmentId { get; set; }

        public int ModuleId { get; set; }
        public int SubModuleId { get; set; }

        [Required(ErrorMessage = "From Date is required")]
        [DataType(DataType.Date)]
        public DateTime? DateFrom { get; set; }

        [Required(ErrorMessage = "To Date is required")]
        [DataType(DataType.Date)]
        public DateTime? DateTo { get; set; }
    }

    public class IssueReportRowViewModel
    {
        public int? Id { get; set; }
        public int?  TotalIssueLogged { get; set; }
        public int? TotalIssueResolved { get; set; }
        public int? TotalIssuePending { get; set; }
        public decimal? ResolutionRate { get; set; }
        public string AverageResolutionTime { get; set; }
    }

    public class DrillDownItemViewModel
    {
        public int? Id { get; set; }
        public string IssueId { get; set; }
        public string DepartmentName { get; set; }
        public string ModuleName { get; set; }
        public string SubModuleName { get; set; }
        public string SeverityName { get; set; }
        public string CreatedDate { get; set; }
        public string Status { get; set; }
        public string PendingAt { get; set; }
    }


    public class IssueReportViewModel
    {
        public IssueReportFilterViewModel Filter { get; set; } = new();

        public List<SelectListItem> Departments { get; set; } = new();
        public List<SelectListItem> Modules { get; set; } = new();
        public List<SelectListItem> SubModules { get; set; } = new();

        public List<GrievanceCountResponse> IssueReports { get; set; } = new();

        public List<GrievanceCountDetailResponse> DrillDownItems { get; set; } = new();
    }

    public class DateGreaterThanAttribute : ValidationAttribute
    {
        private readonly string _otherPropertyName;
        public DateGreaterThanAttribute(string otherPropertyName)
        {
            _otherPropertyName = otherPropertyName;
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var otherProperty = validationContext.ObjectType.GetProperty(_otherPropertyName);
            if (otherProperty == null) return ValidationResult.Success;

            var otherDate = otherProperty.GetValue(validationContext.ObjectInstance) as DateTime?;
            var thisDate = value as DateTime?;

            if (thisDate.HasValue && otherDate.HasValue && thisDate < otherDate)
            {
                return new ValidationResult(ErrorMessage);
            }
            return ValidationResult.Success;
        }
    }
}
